export type Locale = 'fr' | 'ar';

export interface NavContent {
  home: string; formations: string; programme: string; tarifs: string;
  galerie: string; blog: string; faq: string; contact: string;
}
export interface Stat { big: string; label: string; }
export interface Benefit { num: string; title: string; desc: string; }
export interface Program {
  key: string; name: string; level: string; levelLabel: string; dur: string;
  price: string; priceNote: string; img: string; featured: boolean;
  desc: string; points: string[];
}
export interface Module { title: string; desc: string; points: string[]; }
export interface Testimonial { quote: string; name: string; role: string; initials: string; }
export interface FAQ { q: string; a: string; }
export interface GalleryCat { token: string; label: string; }
export interface Session { key: string; title: string; desc: string; }
export interface Post { slug: string; cat: string; date: string; img: string; title: string; excerpt: string; body: string[]; }
export interface Filter { token: string; label: string; }

export interface LocaleContent {
  dir: 'ltr' | 'rtl';
  nav: NavContent;
  ui: Record<string, string>;
  stats: Stat[];
  marquee: string;
  benefits: Benefit[];
  programs: Program[];
  filters: Filter[];
  modules: Module[];
  testimonials: Testimonial[];
  faqs: FAQ[];
  galleryCats: GalleryCat[];
  sessions: Session[];
  posts: Post[];
}

export const galleryMap = [
  { src: '/assets/photo/p5.jpg', cats: ['espresso'] },
  { src: '/assets/photo/p3.jpg', cats: ['espresso', 'machines'] },
  { src: '/assets/photo/p8.jpg', cats: ['latte'] },
  { src: '/assets/photo/p7.jpg', cats: ['latte', 'coaching'] },
  { src: '/assets/photo/p9.jpg', cats: ['latte', 'slowbar'] },
  { src: '/assets/photo/p6.jpg', cats: ['slowbar'] },
  { src: '/assets/photo/p1.jpg', cats: ['coaching'] },
  { src: '/assets/photo/p2.jpg', cats: ['coaching'] },
  { src: '/assets/photo/p4.jpg', cats: ['machines'] },
];

const content: Record<Locale, LocaleContent> = {
  fr: {
    dir: 'ltr',
    nav: {
      home: 'Accueil', formations: 'Formations', programme: 'Programme',
      tarifs: 'Tarifs', galerie: 'Galerie', blog: 'Journal', faq: 'FAQ', contact: 'Contact',
    },
    ui: {
      cta_enroll: "S'inscrire", cta_whatsapp: 'WhatsApp',
      cta_view_formations: 'Les formations', cta_view_programme: 'Voir le programme',
      cta_view_all: 'Tout voir', cta_view_gallery: 'Galerie', cta_details: 'Détails',
      featured: 'Le plus choisi', cta_book: 'Réserver', cta_quote: 'Demander un devis',
      email_ph: 'Votre e-mail', news_ok: 'Merci\u00a0! Vous êtes inscrit à notre journal.',
      f_name: 'Nom complet', f_email: 'E-mail', f_phone: 'Téléphone',
      f_program: 'Formation', f_session: 'Session', f_level: 'Niveau',
      f_goals: 'Vos objectifs', f_message: 'Message', f_date: 'Date de session souhaitée',
      form_ok_title: 'Demande envoyée',
      form_ok_sub: 'Notre équipe vous recontacte sous 24h. Finalisez plus vite sur WhatsApp.',
      book_tag: 'Réserver une place', book_title: 'Réserver ma place',
      book_submit: 'Envoyer ma demande',
      book_note: "Aucun paiement en ligne. Avance confirmée par l'académie.",
      err_required: 'Champ requis', err_phone: 'Téléphone invalide', err_email: 'E-mail invalide',
      choose_session: 'Choisir une session', included: 'Ce qui est inclus',
      hero_eyebrow: 'Barista · Latte Art · Mixologie',
      hero_title: 'Devenez barista & mixologue professionnel',
      hero_sub: "Des formations pro en Barista, Latte Art et Mixologie, alliant théorie et pratique — des bases essentielles aux techniques avancées et à la créativité, autour des boissons chaudes et froides.",
      about_eyebrow: "L'académie", about_title: 'Pensée comme un véritable coffee lab',
      about_p1: "Barista Moroccan Academy forme aux métiers du café et de la mixologie\u00a0: on apprend la main à la pâte, sur matériel professionnel — machine, moulin et bar — avec café, lait, fruits et sirops fournis.",
      about_p2: "70% du temps est consacré à la pratique, en petits groupes de 8 à 10. Un certificat « Barista & Mixology Pro Masterclass » est délivré en fin de formation.",
      why_eyebrow: 'Pourquoi nous', why_title: 'Pourquoi choisir Barista Moroccan Academy',
      programs_eyebrow: 'Nos formations', programs_title: 'Choisissez votre formule',
      curriculum_eyebrow: 'Le programme', curriculum_title: '3 modules, du café au cocktail',
      curriculum_cta: 'Programme complet',
      gallery_eyebrow: 'En atelier', gallery_title: "L'académie en images",
      testi_eyebrow: 'Témoignages', testi_title: 'Ils sont passés derrière la machine',
      cta_b2c_tag: 'Particuliers', cta_b2c_title: 'Lancez votre carrière barista',
      cta_b2c_sub: "Débutant ou en reconversion\u00a0: repartez avec un vrai savoir-faire et une attestation.",
      cta_b2b_tag: 'Entreprises & CHR', cta_b2b_title: 'Formez votre équipe',
      cta_b2b_sub: "Cafés, hôtels et restaurants\u00a0: un format sur mesure pour monter le niveau de vos baristas.",
      cta_b2b_btn: "Parler à l'équipe",
      footer_tagline: 'Académie barista basée à Casablanca, pensée comme un coffee lab urbain.',
      footer_nav: 'Navigation', footer_contact: 'Contact',
      footer_address: 'Urban Coffee Lab, Casablanca, Maroc',
      footer_news: 'Journal', footer_news_sub: 'Conseils café et dates de sessions, sans spam.',
      footer_made: 'Casablanca · Maroc',
      formations_sub: "Deux formules — en groupe ou en privé — du premier espresso à la mixologie moderne.",
      tarifs_eyebrow: 'Tarifs', tarifs_title: 'Des tarifs clairs, sans surprise',
      tarifs_sub: 'Deux formules, fournitures incluses (café, lait, fruits, sirops). Pas de frais cachés.',
      tarifs_note: "La réservation est confirmée après le règlement d'une avance ; le paiement complet est effectué avant le début de la formation.",
      sessions_title: 'Horaires & formats',
      prog_intro: "Trois modules progressifs — Barista & Latte Art, Mixologie moderne, puis Hygiène & bonnes pratiques. 70% du temps en pratique, sur matériel professionnel.",
      insc_eyebrow: 'Inscription', insc_title: 'Réservez votre place',
      insc_sub: 'Laissez vos coordonnées : nous confirmons la session et les modalités par WhatsApp.',
      insc_submit: 'Envoyer ma demande',
      faq_eyebrow: 'FAQ', faq_title: 'Questions fréquentes',
      faq_sub: "Tout ce qu'il faut savoir avant de vous inscrire.",
      faq_more: 'Une autre question ?', faq_more_btn: 'Contactez-nous',
      contact_eyebrow: 'Contact', contact_title: 'Parlons café',
      contact_sub: 'Une question sur une formation, une session entreprise ou un projet de coffee shop ?',
      contact_form_title: 'Écrivez-nous', contact_send: 'Envoyer le message',
      ci_phone: 'Téléphone / WhatsApp', ci_email: 'E-mail',
      ci_address: 'Adresse', ci_hours: 'Horaires',
      hours_val: 'Lun – Sam · 9h – 19h', map_label: 'Urban Coffee Lab · Casablanca',
      blog_eyebrow: 'Journal', blog_title: 'Conseils & culture café',
      blog_sub: 'Techniques, latte art et business : ce que nous transmettons en atelier.',
      blog_read: "Lire l'article", blog_back: '← Retour au journal', blog_all: 'Tous les articles',
      galerie_cert_title: 'Certificats à venir',
      galerie_cert_sub: 'Les attestations de participation sont remises en fin de session. Les photos seront ajoutées prochainement.',
      inscription_link: '/fr/inscription',
    },
    stats: [
      { big: '70%', label: 'Pratique en atelier' },
      { big: '8–10', label: 'Participants / groupe' },
      { big: '3', label: 'Modules pro' },
      { big: '4h', label: 'Par jour' },
    ],
    marquee: 'BARISTA — LATTE ART — ESPRESSO — MIXOLOGIE — COCKTAILS — MOCKTAILS — SPECIALTY COFFEE — ',
    benefits: [
      { num: '01', title: 'Barista & Latte Art', desc: "Café, espresso, matériel professionnel et Latte Art, des bases aux designs avancés, jusqu'au Specialty Coffee." },
      { num: '02', title: 'Mixologie moderne', desc: 'Boissons froides, mojitos, cocktails et mocktails : techniques de mélange, équilibre des saveurs et boissons signature.' },
      { num: '03', title: 'Prêt pour le métier', desc: 'Hygiène professionnelle, organisation du poste, sécurité, certificat délivré et fournitures incluses.' },
    ],
    programs: [
      {
        key: 'groupe', name: 'Formation en Groupe', level: 'groupe',
        levelLabel: 'Groupe · 8–10', dur: '5 jours · 4h/jour',
        price: '1 500 DH', priceNote: 'par personne',
        img: '/assets/photo/p5.jpg', featured: true,
        desc: 'Barista, Latte Art & mixologie en petit groupe (8 à 10) dans une ambiance dynamique et professionnelle. 70% pratique, 30% théorie.',
        points: ['Barista, Latte Art & Specialty Coffee', 'Mixologie moderne & boissons froides', 'Hygiène, matériel pro & fournitures incluses'],
      },
      {
        key: 'privee', name: 'Formation Privée', level: 'privee',
        levelLabel: 'Privé · sur mesure', dur: '3 jours · 4h/jour',
        price: '3 000 DH', priceNote: 'par personne',
        img: '/assets/photo/p3.jpg', featured: false,
        desc: 'Une formule personnalisée centrée sur vos objectifs : Latte Art, café ou mixologie, avec un accompagnement approfondi.',
        points: ['Programme 100% personnalisé', 'Pratique approfondie & rythme adapté', 'Focus Latte Art, café ou mixologie'],
      },
    ],
    filters: [
      { token: 'all', label: 'Toutes' },
      { token: 'groupe', label: 'En groupe' },
      { token: 'privee', label: 'Privée' },
    ],
    modules: [
      {
        title: 'Module 1 — Barista & Latte Art',
        desc: "L'univers du café et les bases professionnelles du métier de barista.",
        points: ['Origine du café, variétés & torréfaction', 'Matériel pro : machine, moulin, accessoires', 'Boissons café internationales', 'Latte Art, des bases aux designs avancés', 'Boissons signature à base de café', 'Introduction au Specialty Coffee & méthodes'],
      },
      {
        title: 'Module 2 — Mixologie moderne',
        desc: 'Les boissons froides et la présentation professionnelle derrière le bar.',
        points: ["Organisation & gestion d'un bar", 'Boissons froides internationales', 'Mojitos, cocktails & mocktails', 'Techniques de mélange & équilibre des saveurs', 'Création de boissons signature', 'Présentation & valorisation des boissons'],
      },
      {
        title: 'Module 3 — Hygiène & bonnes pratiques',
        desc: "Les règles essentielles pour travailler dans un environnement professionnel.",
        points: ["Normes d'hygiène professionnelles", 'Organisation du poste de travail', 'Sécurité & qualité de service', 'Bonnes pratiques pour travailler efficacement'],
      },
    ],
    testimonials: [
      { quote: 'Pédagogie claire, beaucoup de pratique et vraie confiance derrière la machine.', name: 'Imane', role: 'Future barista', initials: 'IM' },
      { quote: "Le module coûts et workflow m'a aidé à structurer mon coffee shop.", name: 'Yassine', role: 'Porteur de projet', initials: 'YA' },
    ],
    faqs: [
      { q: 'Faut-il avoir une expérience ?', a: "Non. Les sessions sont adaptées aux débutants comme aux niveaux intermédiaires ; les bases sont reprises depuis zéro." },
      { q: 'Recevrai-je un certificat ?', a: 'Oui, le certificat « Barista & Mixology Pro Masterclass » est délivré en fin de formation.' },
      { q: 'Les dates sont-elles fixes ?', a: 'Les sessions (matin ou après-midi) sont confirmées par WhatsApp selon les places disponibles.' },
      { q: 'Comment se passe le paiement ?', a: "La réservation est confirmée après le règlement d'une avance ; le solde est réglé avant le début de la formation." },
      { q: 'Quelle différence entre groupe et privé ?', a: 'La formation en groupe dure 5 jours (8 à 10 participants) à 1 500 DHS ; la formation privée dure 3 jours, sur mesure, à 3 000 DHS par personne.' },
    ],
    galleryCats: [
      { token: 'all', label: 'Tout' }, { token: 'espresso', label: 'Atelier espresso' },
      { token: 'latte', label: 'Latte art' }, { token: 'slowbar', label: 'Slow coffee bar' },
      { token: 'coaching', label: 'Coaching' }, { token: 'machines', label: 'Machines & moulins' },
      { token: 'certificats', label: 'Certificats' },
    ],
    sessions: [
      { key: 'matin', title: 'Session matin', desc: 'De 09h30 à 13h30, avec une pause de 15 minutes — 4 heures par jour.' },
      { key: 'apresmidi', title: 'Session après-midi', desc: 'De 14h30 à 18h30, avec une pause de 15 minutes — 4 heures par jour.' },
      { key: 'privee', title: 'Formule privée', desc: 'Sur mesure, 3 jours, centrée sur vos objectifs et votre rythme.' },
    ],
    posts: [
      {
        slug: 'extraction-espresso', cat: 'Technique', date: '12 Mai 2026',
        img: '/assets/photo/p3.jpg',
        title: 'Réussir son extraction espresso : dose, temps, rendement',
        excerpt: 'Les trois variables qui changent tout dans la tasse — et comment les régler au quotidien.',
        body: [
          "Un bon espresso n'est jamais un hasard : c'est l'équilibre entre la dose de café, le temps d'extraction et le poids de la boisson obtenue. En atelier, on apprend à mesurer ces trois variables plutôt qu'à les deviner.",
          "La dose donne la base : trop faible, la tasse est creuse ; trop forte, elle bloque l'eau. Le rendement (le ratio entre café sec et boisson) oriente l'intensité, tandis que le temps révèle si la mouture est bien réglée.",
          "La clé est la constance : noter ses réglages, goûter, ajuster d'un cran à la fois. C'est exactement la méthode que nous transmettons derrière la machine.",
        ],
      },
      {
        slug: 'latte-art-debuter', cat: 'Technique', date: '28 Avril 2026',
        img: '/assets/photo/p7.jpg',
        title: 'Latte art : de la texture du lait à la première rosetta',
        excerpt: 'Tout commence par un lait bien texturé. Voici la progression que nous enseignons en atelier.',
        body: [
          "Avant le dessin, il y a la matière : un lait correctement texturé, brillant, sans grosses bulles. Sans cette base, aucune figure ne tient.",
          "On démarre par le cœur, puis la tulipe, et enfin la rosetta. Chaque étape travaille un geste précis : hauteur de la verse, vitesse et mouvement du poignet.",
          "La répétition fait le reste. En groupe limité, chacun reçoit un retour immédiat du coach pour corriger le geste avant qu'il ne devienne une habitude.",
        ],
      },
      {
        slug: 'mixologie-mocktails', cat: 'Mixologie', date: '10 Avril 2026',
        img: '/assets/photo/p9.jpg',
        title: "Mixologie : les bases d'un mocktail signature réussi",
        excerpt: 'Équilibre des saveurs, techniques de mélange et présentation : ce qui fait un bon mocktail.',
        body: [
          "La mixologie moderne ne se limite pas aux cocktails : mojitos, boissons froides et mocktails demandent les mêmes fondamentaux — un bon équilibre entre acidité, sucre et amertume.",
          "La technique de mélange compte autant que la recette : savoir doser, secouer ou remuer change complètement la texture et l'intensité du verre.",
          "Enfin, la présentation valorise la boisson. En atelier, on travaille le dressage, le verre et la garniture pour servir un mocktail aussi beau que bon.",
        ],
      },
    ],
  },

  ar: {
    dir: 'rtl',
    nav: {
      home: 'الرئيسية', formations: 'التكوينات', programme: 'البرنامج',
      tarifs: 'الأسعار', galerie: 'المعرض', blog: 'المدونة', faq: 'الأسئلة', contact: 'اتصل بنا',
    },
    ui: {
      cta_enroll: 'سجّل الآن', cta_whatsapp: 'واتساب',
      cta_view_formations: 'التكوينات', cta_view_programme: 'عرض البرنامج',
      cta_view_all: 'عرض الكل', cta_view_gallery: 'المعرض', cta_details: 'التفاصيل',
      featured: 'الأكثر اختياراً', cta_book: 'احجز مقعدك', cta_quote: 'اطلب عرض سعر',
      email_ph: 'بريدك الإلكتروني', news_ok: 'شكراً! تم تسجيلك في مدونتنا.',
      f_name: 'الاسم الكامل', f_email: 'البريد الإلكتروني', f_phone: 'الهاتف',
      f_program: 'التكوين', f_session: 'الدورة', f_level: 'المستوى',
      f_goals: 'أهدافك', f_message: 'الرسالة', f_date: 'تاريخ الحصة المطلوب',
      form_ok_title: 'تم إرسال الطلب',
      form_ok_sub: 'سيتواصل معك فريقنا خلال 24 ساعة. أكمل بسرعة عبر واتساب.',
      book_tag: 'احجز مقعدك', book_title: 'حجز مقعدي', book_submit: 'إرسال الطلب',
      book_note: 'لا يوجد دفع عبر الإنترنت. العربون يُؤكَّد من طرف الأكاديمية.',
      err_required: 'حقل مطلوب', err_phone: 'رقم هاتف غير صحيح', err_email: 'بريد إلكتروني غير صحيح',
      choose_session: 'اختر حصتك', included: 'ما يتضمنه التكوين',
      hero_eyebrow: 'باريستا · لاتيه آرت · ميكسولوجي',
      hero_title: 'احترف صنع القهوة والمشروبات من الصفر',
      hero_sub: 'أكاديمية الباريستا المغربية تقدم تكوينات عملية متخصصة في الباريستا، اللاتيه آرت والميكسولوجي — بمعدات احترافية وتأطير خبراء، لتخرج مستعداً لسوق العمل من اليوم الأول.',
      about_eyebrow: 'من نحن', about_title: 'ورشة تكوين احترافية في قلب الدار البيضاء',
      about_p1: 'في أكاديمية الباريستا المغربية، نؤمن بأن الممارسة الميدانية هي أسرع طريق للاحتراف. تتدرب على معدات حقيقية في أجواء تشبه الوسط المهني — مع كامل المستلزمات من قهوة وحليب وفواكه وسيروب.',
      about_p2: 'من وقت التكوين مخصص للتطبيق العملي، في مجموعات لا تتجاوز 10 مشاركين. يُتوَّج مسارك بشهادة «Barista & Mixology Pro Masterclass» تُسلَّم بعد التقييم النهائي. %70',
      why_eyebrow: 'لماذا نحن', why_title: 'ماذا ستتعلم معنا',
      programs_eyebrow: 'تكويناتنا', programs_title: 'اختر صيغتك',
      curriculum_eyebrow: 'البرنامج', curriculum_title: '3 محاور، من القهوة إلى الكوكتيل',
      curriculum_cta: 'البرنامج الكامل',
      gallery_eyebrow: 'من داخل الورشة', gallery_title: 'لحظات من قلب التكوين',
      testi_eyebrow: 'قالوا عنا', testi_title: 'تجارب خرّيجينا',
      cta_b2c_tag: 'للأفراد', cta_b2c_title: 'ابدأ مشوارك في عالم القهوة',
      cta_b2c_sub: 'سواء كنت مبتدئاً أو تبحث عن تغيير مسارك المهني، نمنحك مهارة حقيقية وشهادة معترف بها.',
      cta_b2b_tag: 'للمقاهي والمطاعم', cta_b2b_title: 'ارفع مستوى فريقك',
      cta_b2b_sub: 'نصمم تكويناً خاصاً لفرق المقاهي والفنادق والمطاعم، يرفع جودة الخدمة ويوحّد المعايير.',
      cta_b2b_btn: 'تواصل معنا',
      footer_tagline: 'أكاديمية لتكوين الباريستا في الدار البيضاء، بروح معمل قهوة حضري.',
      footer_nav: 'روابط', footer_contact: 'للتواصل',
      footer_address: 'Urban Coffee Lab، الدار البيضاء، المغرب',
      footer_news: 'المدونة', footer_news_sub: 'نصائح في القهوة ومواعيد الدورات، بدون إزعاج.',
      footer_made: 'الدار البيضاء · المغرب',
      formations_sub: 'صيغتان للتكوين — جماعية أو خاصة — تأخذك من أول كوب إسبريسو إلى فنون الميكسولوجي.',
      tarifs_eyebrow: 'الأسعار', tarifs_title: 'أثمنة واضحة بدون مفاجآت',
      tarifs_sub: 'صيغتان شاملتان للمستلزمات (قهوة، حليب، فواكه وسيروب). بدون رسوم خفية.',
      tarifs_note: 'يُحجز مقعدك بعد دفع عربون، ويُستكمل باقي المبلغ قبل انطلاق التكوين.',
      sessions_title: 'الحصص والصيغ',
      prog_intro: 'ثلاثة محاور متكاملة — الباريستا واللاتيه آرت، ثم الميكسولوجي الحديث، فالنظافة والممارسات المهنية. 70% من الوقت تطبيق عملي على معدات احترافية.',
      insc_eyebrow: 'التسجيل', insc_title: 'احجز مقعدك الآن',
      insc_sub: 'اترك معلوماتك وسنتواصل معك عبر واتساب لتأكيد الحصة والتفاصيل.',
      insc_submit: 'أرسل طلبي',
      faq_eyebrow: 'أسئلتكم', faq_title: 'أسئلة يطرحها الكثيرون',
      faq_sub: 'جمعنا لك أهم ما تحتاج معرفته قبل التسجيل.',
      faq_more: 'لم تجد جوابك؟', faq_more_btn: 'تواصل معنا',
      contact_eyebrow: 'تواصل معنا', contact_title: 'يسعدنا أن نسمع منك',
      contact_sub: 'استفسار حول تكوين، دورة لفريق عمل أو مشروع مقهى؟ نحن هنا.',
      contact_form_title: 'راسلنا مباشرة', contact_send: 'أرسل رسالتك',
      ci_phone: 'الهاتف / واتساب', ci_email: 'البريد الإلكتروني',
      ci_address: 'العنوان', ci_hours: 'أوقات العمل',
      hours_val: 'الإثنين – السبت · 9ص – 7م', map_label: 'Urban Coffee Lab · الدار البيضاء',
      blog_eyebrow: 'المدونة', blog_title: 'من عالم القهوة',
      blog_sub: 'تقنيات، لاتيه آرت وأسرار المهنة: ما نشاركه داخل الورشة وخارجها.',
      blog_read: 'تابع القراءة', blog_back: '→ العودة إلى المدونة', blog_all: 'كل المقالات',
      galerie_cert_title: 'صور الشهادات قريباً',
      galerie_cert_sub: 'تُسلَّم الشهادات في ختام كل دورة، وسنضيف صورها هنا قريباً.',
      inscription_link: '/ar/inscription',
    },
    stats: [
      { big: '70%', label: 'تطبيق داخل الورشة' },
      { big: '8–10', label: 'مشارك / مجموعة' },
      { big: '3', label: 'محاور احترافية' },
      { big: '4h', label: 'ساعات يومياً' },
    ],
    marquee: 'باريستا — لاتيه آرت — إسبريسو — ميكسولوجي — كوكتيلات — موكتيلات — قهوة مختصة — ',
    benefits: [
      { num: '01', title: 'فن الباريستا واللاتيه', desc: "تتعلّم استخلاص الإسبريسو وضبط الآلة والمطحنة، ثم ترسم باللاتيه آرت من القلب البسيط إلى أعقد التصاميم، وصولاً إلى عالم القهوة المختصة." },
      { num: '02', title: 'إبداع الميكسولوجي', desc: 'تدخل عالم المشروبات الباردة والموهيتو والموكتيلات، وتتقن المزج وتوازن النكهات لابتكار مشروباتك الخاصة بلمسة احترافية.' },
      { num: '03', title: 'استعداد لسوق العمل', desc: 'تتدرّب على معايير النظافة وتنظيم محطة العمل والسلامة، وتختم مسارك بشهادة مهنية تفتح لك أبواب المقاهي والفنادق.' },
    ],
    programs: [
      {
        key: 'groupe', name: 'التكوين الجماعي', level: 'groupe',
        levelLabel: 'جماعي · 8–10', dur: '5 أيام · 4 ساعات يومياً',
        price: '1 500 DH', priceNote: 'للشخص',
        img: '/assets/photo/p5.jpg', featured: true,
        desc: 'تجربة تكوين كاملة تجمع الباريستا واللاتيه آرت والميكسولوجي، في مجموعة صغيرة تضمن متابعة شخصية لكل مشارك. التركيز على التطبيق العملي (70%).',
        points: ['باريستا، لاتيه آرت وقهوة مختصة', 'ميكسولوجي حديث ومشروبات باردة', 'المعدات واللوازم مشمولة بالكامل'],
      },
      {
        key: 'privee', name: 'التكوين الخاص', level: 'privee',
        levelLabel: 'خاص · حسب الطلب', dur: '3 أيام · 4 ساعات يومياً',
        price: '3 000 DH', priceNote: 'للشخص',
        img: '/assets/photo/p3.jpg', featured: false,
        desc: 'تكوين فردي يدور بالكامل حول أهدافك وإيقاعك، سواء أردت التعمق في اللاتيه آرت، القهوة أو الميكسولوجي، بمرافقة فردية من المدرب.',
        points: ['برنامج مصمّم خصيصاً لك', 'اهتمام فردي وإيقاع مرن', 'تركيز على مجالك المفضّل'],
      },
    ],
    filters: [
      { token: 'all', label: 'الكل' },
      { token: 'groupe', label: 'جماعي' },
      { token: 'privee', label: 'خاص' },
    ],
    modules: [
      {
        title: 'المحور الأول — الباريستا واللاتيه آرت',
        desc: 'تدخل عالم القهوة من بابه الواسع، وتبني أساساً احترافياً متيناً في مهنة الباريستا.',
        points: ['أصل القهوة وأنواعها ومراحل التحميص', 'التعامل مع الآلة والمطحنة والملحقات', 'تحضير مشروبات القهوة العالمية', 'اللاتيه آرت من أول قلب إلى التصاميم المتقدمة', 'ابتكار مشروبات قهوة مميزة', 'مدخل إلى القهوة المختصة وطرق التحضير اليدوية'],
      },
      {
        title: 'المحور الثاني — الميكسولوجي الحديث',
        desc: 'تنتقل إلى عالم المشروبات الباردة والإبداع خلف البار بأسلوب احترافي.',
        points: ['تنظيم البار وإدارة العمل', 'تحضير المشروبات الباردة العالمية', 'الموهيتو والكوكتيلات والموكتيلات', 'تقنيات المزج وتوازن النكهات', 'تصميم مشروبات تحمل بصمتك', 'فن التقديم والتزيين'],
      },
      {
        title: 'المحور الثالث — النظافة والممارسات المهنية',
        desc: 'تتقن القواعد التي تفصل بين الهاوي والمحترف في أي بيئة عمل.',
        points: ['معايير النظافة المهنية', 'تنظيم محطة العمل', 'السلامة وجودة الخدمة', 'عادات عمل ترفع مردوديتك'],
      },
    ],
    testimonials: [
      { quote: 'خرجت من التكوين وأنا واثقة تماماً خلف الآلة. التطبيق العملي كان أكثر بكثير مما توقعت، والتأطير قريب ومباشر.', name: 'إيمان', role: 'باريستا مبتدئة', initials: 'إ' },
      { quote: 'محور البار والميكسولوجي غيّر نظرتي للمشروبات الباردة. اليوم أصمّم قائمة مقهاي بثقة وبهوية خاصة.', name: 'ياسين', role: 'صاحب مشروع مقهى', initials: 'ي' },
    ],
    faqs: [
      { q: 'هل أحتاج خبرة سابقة للالتحاق؟', a: 'إطلاقاً. نبدأ معك من الصفر ونبني المهارة خطوة بخطوة، سواء كنت مبتدئاً تماماً أو لديك بعض الأساسيات.' },
      { q: 'ماذا أستفيد في نهاية التكوين؟', a: 'تحصل على شهادة «Barista & Mixology Pro Masterclass» بعد اجتياز التقييم النهائي، إلى جانب خبرة عملية حقيقية.' },
      { q: 'كيف أختار موعد الحصة؟', a: 'تختار بين حصة صباحية أو مسائية، ونؤكد لك الموعد عبر واتساب حسب الأماكن المتاحة.' },
      { q: 'كيف يتم الأداء والحجز؟', a: 'يُثبّت مقعدك بدفع عربون، ثم تستكمل باقي المبلغ قبل انطلاق الدورة.' },
      { q: 'أيهما أناسبني: الجماعي أم الخاص؟', a: 'الجماعي (5 أيام، 8–10 مشاركين بـ 1 500 درهم) مثالي للأجواء التفاعلية؛ والخاص (3 أيام بـ 3 000 درهم) أنسب لمن يريد برنامجاً مخصصاً وإيقاعاً خاصاً.' },
    ],
    galleryCats: [
      { token: 'all', label: 'الكل' }, { token: 'espresso', label: 'ورشة الإسبريسو' },
      { token: 'latte', label: 'لاتيه آرت' }, { token: 'slowbar', label: 'بار القهوة البطيئة' },
      { token: 'coaching', label: 'التأطير' }, { token: 'machines', label: 'الآلات والمطاحن' },
      { token: 'certificats', label: 'الشهادات' },
    ],
    sessions: [
      { key: 'matin', title: 'الحصة الصباحية', desc: 'من الساعة 09:30 إلى 13:30، مع استراحة قصيرة — أربع ساعات من التدريب يومياً.' },
      { key: 'apresmidi', title: 'الحصة المسائية', desc: 'من الساعة 14:30 إلى 18:30، مع استراحة قصيرة — مثالية لمن تشغله الصباح.' },
      { key: 'privee', title: 'الصيغة الخاصة', desc: 'ثلاثة أيام حسب الطلب، بجدول وأهداف تُرسم حسب احتياجك.' },
    ],
    posts: [
      {
        slug: 'extraction-espresso', cat: 'تقنية', date: '12 ماي 2026',
        img: '/assets/photo/p3.jpg',
        title: 'إتقان استخلاص الإسبريسو: الجرعة، الوقت والعائد',
        excerpt: 'ثلاثة متغيرات تغيّر كل شيء في الكوب — وكيفية ضبطها يومياً.',
        body: [
          'الإسبريسو الجيد ليس صدفة: إنه توازن بين جرعة القهوة، وقت الاستخلاص ووزن المشروب الناتج. داخل الورشة نتعلّم قياس هذه المتغيرات بدل تخمينها.',
          'الجرعة تعطي الأساس، والعائد يوجّه الكثافة، بينما يكشف الوقت ما إذا كانت المطحنة مضبوطة جيداً.',
          'المفتاح هو الثبات: تدوين الإعدادات، التذوق، والتعديل درجة واحدة في كل مرة. هذه بالضبط هي المنهجية التي ننقلها خلف الآلة.',
        ],
      },
      {
        slug: 'latte-art-debuter', cat: 'تقنية', date: '28 أبريل 2026',
        img: '/assets/photo/p7.jpg',
        title: 'لاتيه آرت: من قوام الحليب إلى أول روزيتا',
        excerpt: 'كل شيء يبدأ بحليب جيد القوام. إليك التدرّج الذي نعلّمه داخل الورشة.',
        body: [
          'قبل الرسم هناك المادة: حليب جيد القوام، لامع، بدون فقاعات كبيرة. بدون هذا الأساس لا يثبت أي شكل.',
          'نبدأ بالقلب، ثم التوليب، وأخيراً الروزيتا. كل مرحلة تشتغل على حركة دقيقة: ارتفاع السكب، السرعة وحركة المعصم.',
          'التكرار يفعل الباقي. ضمن مجموعة محدودة يتلقى كل متدرب ملاحظة فورية من المدرب.',
        ],
      },
      {
        slug: 'mixologie-mocktails', cat: 'ميكسولوجي', date: '10 أبريل 2026',
        img: '/assets/photo/p9.jpg',
        title: 'الميكسولوجي: أساسيات موكتيل مميز ناجح',
        excerpt: 'توازن النكهات، تقنيات المزج والتقديم: ما يصنع موكتيلاً جيداً.',
        body: [
          'الميكسولوجي الحديث لا يقتصر على الكوكتيلات: الموهيتو، المشروبات الباردة والموكتيلات تتطلب نفس الأساسيات — توازن جيد بين الحموضة، السكر والمرارة.',
          'تقنية المزج لا تقل أهمية عن الوصفة: معرفة الجرعات، الرجّ أو التحريك تغيّر تماماً قوام وكثافة الكوب.',
          'أخيراً، التقديم يبرز المشروب. داخل الورشة نشتغل على التنسيق، الكأس والتزيين لتقديم موكتيل جميل ولذيذ.',
        ],
      },
    ],
  },
};

export function getContent(locale: string): LocaleContent {
  return content[locale as Locale] ?? content.fr;
}

export function getFonts(dir: string) {
  return dir === 'rtl'
    ? { display: "'Tajawal', sans-serif", body: "'Cairo', sans-serif" }
    : { display: "'Anton', sans-serif", body: "'Archivo', sans-serif" };
}
