export const locales = ['fr', 'ar'] as const;
export type Locale = (typeof locales)[number];
export const defaultLocale: Locale = 'fr';

export const WHATSAPP = 'https://wa.me/212657116631';
export const PHONE = '+212 657 116 631';
export const EMAIL = 'contact@wedrinks.ma';
export const ADDRESS_FR = 'Urban Coffee Lab, Casablanca, Maroc';
export const ADDRESS_AR = 'Urban Coffee Lab، الدار البيضاء، المغرب';

export const NAV_PAGES = [
  'home', 'formations', 'programme', 'tarifs', 'galerie', 'blog', 'faq', 'contact',
] as const;

export function getLocalePath(locale: string, page: string): string {
  if (page === 'home') return `/${locale}`;
  return `/${locale}/${page}`;
}
