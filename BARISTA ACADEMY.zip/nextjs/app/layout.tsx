import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Barista Moroccan Academy — Casablanca',
  description: 'Formations Barista, Latte Art & Mixologie à Casablanca. Urban Coffee Lab by STE Wedrinks.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html>
      <body>{children}</body>
    </html>
  );
}
