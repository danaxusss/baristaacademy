import Link from 'next/link';
import { getContent, getFonts } from '@/lib/content';
import FaqAccordion from '@/components/FaqAccordion';

export function generateStaticParams() {
  return [{ locale: 'fr' }, { locale: 'ar' }];
}

export default function FaqPage({ params }: { params: { locale: string } }) {
  const { locale } = params;
  const c = getContent(locale);
  const u = c.ui;
  const fonts = getFonts(c.dir);

  return (
    <>
      <div style={{ background: '#120D0A', borderBottom: '1px solid rgba(255,255,255,.08)', padding: 'clamp(52px,7vw,86px) 24px clamp(36px,4vw,52px)' }}>
        <div style={{ maxWidth: 1240, margin: '0 auto' }}>
          <div style={{ fontSize: 13, fontWeight: 700, letterSpacing: '.16em', textTransform: 'uppercase' as const, color: '#C8602B', marginBottom: 16 }}>{u.faq_eyebrow}</div>
          <h1 style={{ fontFamily: fonts.display, fontWeight: 400, fontSize: 'clamp(38px,6.5vw,76px)', lineHeight: .94, textTransform: 'uppercase' as const, marginBottom: 18 }}>{u.faq_title}</h1>
          <p style={{ color: '#C9C0B5', fontSize: 18, maxWidth: 560 }}>{u.faq_sub}</p>
        </div>
      </div>

      <section style={{ background: '#0E0D0C', padding: 'clamp(48px,6vw,80px) 24px clamp(64px,9vw,100px)' }}>
        <div style={{ maxWidth: 860, margin: '0 auto' }}>
          <FaqAccordion faqs={c.faqs} fonts={fonts} />
          <div style={{ marginTop: 48, textAlign: 'center', background: '#16110D', border: '1px solid rgba(255,255,255,.08)', borderRadius: 8, padding: '40px 24px' }}>
            <h3 style={{ fontFamily: fonts.display, fontWeight: 400, fontSize: 28, textTransform: 'uppercase' as const, marginBottom: 18 }}>{u.faq_more}</h3>
            <Link href={`/${locale}/contact`} style={{ background: '#C8602B', color: '#160F0B', fontWeight: 700, textTransform: 'uppercase' as const, letterSpacing: '.04em', fontSize: 14, padding: '15px 28px', borderRadius: 2, display: 'inline-block' }}>{u.faq_more_btn} →</Link>
          </div>
        </div>
      </section>
    </>
  );
}
