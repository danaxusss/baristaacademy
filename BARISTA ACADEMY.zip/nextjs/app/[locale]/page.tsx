import Link from 'next/link';
import { getContent, getFonts, galleryMap } from '@/lib/content';

export function generateStaticParams() {
  return [{ locale: 'fr' }, { locale: 'ar' }];
}

export default function HomePage({ params }: { params: { locale: string } }) {
  const { locale } = params;
  const c = getContent(locale);
  const u = c.ui;
  const fonts = getFonts(c.dir);
  const galleryTeaser = galleryMap.slice(0, 5).map(g => g.src);
  const marqRepeat = c.marquee.repeat(6);

  return (
    <>
      {/* ── HERO ── */}
      <section style={{ position: 'relative', overflow: 'hidden', borderBottom: '1px solid rgba(255,255,255,.08)' }}>
        <div style={{ position: 'absolute', inset: 0, zIndex: 0 }}>
          <img src="/assets/photo/p4.jpg" alt="" style={{ width: '100%', height: '100%', objectFit: 'cover', transform: 'scale(1.14)', filter: 'grayscale(.2) contrast(1.05)' }} />
          <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(100deg,rgba(11,10,9,.96) 30%,rgba(11,10,9,.72) 60%,rgba(11,10,9,.5))' }} />
          <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(120% 90% at 0% 100%,rgba(200,96,43,.22),transparent 55%)' }} />
        </div>
        <div style={{ position: 'relative', zIndex: 1, maxWidth: 1240, margin: '0 auto', padding: 'clamp(64px,11vw,150px) 24px clamp(56px,8vw,110px)' }}>
          <div style={{ maxWidth: 760, animation: 'fadeUp .7s ease both' }}>
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: 10, border: '1px solid rgba(224,163,90,.4)', borderRadius: 100, padding: '7px 15px', marginBottom: 26 }}>
              <span style={{ width: 7, height: 7, borderRadius: '50%', background: '#E0A35A', flexShrink: 0 }} />
              <span style={{ fontSize: 12.5, fontWeight: 700, letterSpacing: '.16em', textTransform: 'uppercase', color: '#E0A35A' as const }}>{u.hero_eyebrow}</span>
            </div>
            <h1 style={{ fontFamily: fonts.display, fontWeight: 400, fontSize: 'clamp(44px,8.5vw,104px)', lineHeight: .92, textTransform: 'uppercase' as const, letterSpacing: '-.01em', marginBottom: 24 }}>{u.hero_title}</h1>
            <p style={{ fontSize: 'clamp(17px,2.2vw,21px)', color: '#C9C0B5', maxWidth: 620, marginBottom: 36, lineHeight: 1.55 }}>{u.hero_sub}</p>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 14 }}>
              <Link href={`/${locale}/inscription`} style={{ display: 'inline-flex', alignItems: 'center', gap: 10, background: '#C8602B', color: '#160F0B', fontWeight: 700, fontSize: 16, letterSpacing: '.04em', textTransform: 'uppercase' as const, padding: '18px 30px', borderRadius: 2 }}>{u.cta_enroll} <span>→</span></Link>
              <Link href={`/${locale}/formations`} style={{ display: 'inline-flex', alignItems: 'center', gap: 10, border: '1px solid rgba(255,255,255,.28)', color: '#F4EEE6', fontWeight: 600, fontSize: 16, letterSpacing: '.02em', textTransform: 'uppercase' as const, padding: '18px 30px', borderRadius: 2 }}>{u.cta_view_formations}</Link>
            </div>
          </div>
        </div>
      </section>

      {/* ── MARQUEE ── */}
      <div style={{ background: '#C8602B', color: '#160F0B', overflow: 'hidden', borderBottom: '1px solid rgba(0,0,0,.15)' }}>
        <div className="animate-marquee" style={{ display: 'flex', whiteSpace: 'nowrap', paddingBlock: 13, fontSize: 13, fontWeight: 700, letterSpacing: '.12em' }}>
          <span style={{ flexShrink: 0 }}>{marqRepeat}</span>
          <span style={{ flexShrink: 0 }}>{marqRepeat}</span>
        </div>
      </div>

      {/* ── STATS ── */}
      <section style={{ background: '#0E0D0C', padding: 'clamp(48px,6vw,72px) 24px', borderBottom: '1px solid rgba(255,255,255,.08)' }}>
        <div style={{ maxWidth: 1240, margin: '0 auto', display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(200px,1fr))', gap: 1, background: 'rgba(255,255,255,.08)', border: '1px solid rgba(255,255,255,.08)' }}>
          {c.stats.map((s, i) => (
            <div key={i} style={{ background: '#0E0D0C', padding: '28px 26px' }}>
              <div style={{ fontFamily: fonts.display, fontSize: 'clamp(34px,4vw,50px)', color: '#E0A35A', lineHeight: 1 }}>{s.big}</div>
              <div style={{ fontSize: 14, color: '#C9C0B5', marginTop: 8, lineHeight: 1.4 }}>{s.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* ── ABOUT ── */}
      <section style={{ background: '#0E0D0C', padding: 'clamp(64px,9vw,120px) 24px' }}>
        <div style={{ maxWidth: 1240, margin: '0 auto', display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(380px,1fr))', gap: 48, alignItems: 'center' }}>
          <div>
            <div style={{ fontSize: 13, fontWeight: 700, letterSpacing: '.16em', textTransform: 'uppercase' as const, color: '#C8602B', marginBottom: 18 }}>{u.about_eyebrow}</div>
            <h2 style={{ fontFamily: fonts.display, fontWeight: 400, fontSize: 'clamp(32px,5vw,60px)', lineHeight: .96, textTransform: 'uppercase' as const, marginBottom: 24 }}>{u.about_title}</h2>
            <p style={{ color: '#C9C0B5', fontSize: 18, marginBottom: 18 }}>{u.about_p1}</p>
            <p style={{ color: '#988F84', marginBottom: 30 }}>{u.about_p2}</p>
            <Link href={`/${locale}/programme`} style={{ display: 'inline-flex', alignItems: 'center', gap: 10, border: '1px solid rgba(255,255,255,.28)', color: '#F4EEE6', fontWeight: 600, textTransform: 'uppercase' as const, letterSpacing: '.02em', fontSize: 14, padding: '15px 24px', borderRadius: 2 }}>{u.cta_view_programme}</Link>
          </div>
          <div style={{ position: 'relative' }}>
            <div style={{ position: 'absolute', inset: '-14px -14px auto auto', width: 120, height: 120, borderTop: '2px solid #C8602B', borderRight: '2px solid #C8602B' }} />
            <div style={{ overflow: 'hidden', borderRadius: 6, border: '1px solid rgba(255,255,255,.1)' }}>
              <img src="/assets/photo/p6.jpg" alt="" style={{ width: '100%', height: 440, objectFit: 'cover' }} />
            </div>
          </div>
        </div>
      </section>

      {/* ── BENEFITS ── */}
      <section style={{ background: '#120D0A', padding: 'clamp(64px,9vw,120px) 24px', borderBlock: '1px solid rgba(255,255,255,.08)' }}>
        <div style={{ maxWidth: 1240, margin: '0 auto' }}>
          <div style={{ fontSize: 13, fontWeight: 700, letterSpacing: '.16em', textTransform: 'uppercase' as const, color: '#C8602B', marginBottom: 16 }}>{u.why_eyebrow}</div>
          <h2 style={{ fontFamily: fonts.display, fontWeight: 400, fontSize: 'clamp(32px,5vw,60px)', lineHeight: .96, textTransform: 'uppercase' as const, marginBottom: 48, maxWidth: 760 }}>{u.why_title}</h2>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(280px,1fr))', gap: 20 }}>
            {c.benefits.map((b, i) => (
              <div key={i} style={{ background: '#0E0D0C', border: '1px solid rgba(255,255,255,.08)', borderRadius: 6, padding: '34px 30px' }}>
                <div style={{ fontFamily: fonts.display, fontSize: 34, color: '#C8602B', marginBottom: 18, lineHeight: 1 }}>{b.num}</div>
                <h3 style={{ fontFamily: fonts.display, fontWeight: 400, fontSize: 26, textTransform: 'uppercase' as const, letterSpacing: '.005em', marginBottom: 14, lineHeight: 1.05 }}>{b.title}</h3>
                <p style={{ color: '#988F84', fontSize: 15.5 }}>{b.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── PROGRAMS PREVIEW ── */}
      <section style={{ background: '#0E0D0C', padding: 'clamp(64px,9vw,120px) 24px' }}>
        <div style={{ maxWidth: 1240, margin: '0 auto' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', flexWrap: 'wrap', gap: 20, marginBottom: 46 }}>
            <div>
              <div style={{ fontSize: 13, fontWeight: 700, letterSpacing: '.16em', textTransform: 'uppercase' as const, color: '#C8602B', marginBottom: 16 }}>{u.programs_eyebrow}</div>
              <h2 style={{ fontFamily: fonts.display, fontWeight: 400, fontSize: 'clamp(32px,5vw,60px)', lineHeight: .96, textTransform: 'uppercase' as const }}>{u.programs_title}</h2>
            </div>
            <Link href={`/${locale}/formations`} style={{ border: '1px solid rgba(255,255,255,.24)', color: '#F4EEE6', fontWeight: 600, textTransform: 'uppercase' as const, letterSpacing: '.03em', fontSize: 13, padding: '13px 22px', borderRadius: 2 }}>{u.cta_view_all}</Link>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(290px,1fr))', gap: 20 }}>
            {c.programs.map(p => (
              <div key={p.key} style={{ background: '#16110D', border: `1px solid ${p.featured ? 'rgba(200,96,43,.5)' : 'rgba(255,255,255,.08)'}`, borderRadius: 7, overflow: 'hidden', transition: 'transform .35s' }}>
                <div style={{ position: 'relative', height: 220, overflow: 'hidden' }}>
                  <img src={p.img} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                  <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg,transparent 40%,rgba(14,13,12,.92))' }} />
                  {p.featured && <div style={{ position: 'absolute', top: 14, insetInlineStart: 14, background: '#C8602B', color: '#160F0B', fontSize: 11, fontWeight: 700, letterSpacing: '.1em', textTransform: 'uppercase' as const, padding: '6px 11px', borderRadius: 2, whiteSpace: 'nowrap' }}>{u.featured}</div>}
                  <div style={{ position: 'absolute', bottom: 14, insetInlineStart: 18, display: 'flex', gap: 8, alignItems: 'center' }}>
                    <span style={{ background: 'rgba(255,255,255,.12)', border: '1px solid rgba(255,255,255,.2)', fontSize: 11, fontWeight: 600, letterSpacing: '.06em', textTransform: 'uppercase' as const, padding: '5px 10px', borderRadius: 2, whiteSpace: 'nowrap' }}>{p.levelLabel}</span>
                    <span style={{ fontSize: 13, color: '#E0A35A', fontWeight: 600, whiteSpace: 'nowrap' }}>{p.dur}</span>
                  </div>
                </div>
                <div style={{ padding: '24px 24px 28px' }}>
                  <h3 style={{ fontFamily: fonts.display, fontWeight: 400, fontSize: 27, textTransform: 'uppercase' as const, lineHeight: 1, marginBottom: 12 }}>{p.name}</h3>
                  <p style={{ color: '#988F84', fontSize: 15, marginBottom: 20, minHeight: 66 }}>{p.desc}</p>
                  <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', gap: 12, borderTop: '1px solid rgba(255,255,255,.08)', paddingTop: 18 }}>
                    <div>
                      <div dir="ltr" style={{ fontFamily: fonts.display, fontSize: 22, color: '#F4EEE6', lineHeight: 1, whiteSpace: 'nowrap' }}>{p.price}</div>
                      <div dir="ltr" style={{ fontSize: 12, color: '#776E64', marginTop: 2 }}>{p.priceNote}</div>
                    </div>
                    <Link href={`/${locale}/formations`} style={{ color: '#E0A35A', fontWeight: 700, textTransform: 'uppercase' as const, letterSpacing: '.04em', fontSize: 13, display: 'inline-flex', alignItems: 'center', gap: 6 }}>{u.cta_details} →</Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CURRICULUM PREVIEW ── */}
      <section style={{ background: '#120D0A', padding: 'clamp(64px,9vw,120px) 24px', borderBlock: '1px solid rgba(255,255,255,.08)' }}>
        <div style={{ maxWidth: 1240, margin: '0 auto', display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(380px,1fr))', gap: 48, alignItems: 'center' }}>
          <div style={{ position: 'relative', order: c.dir === 'rtl' ? 2 : 0 }}>
            <div style={{ overflow: 'hidden', borderRadius: 6, border: '1px solid rgba(255,255,255,.1)' }}>
              <img src="/assets/photo/p5.jpg" alt="" style={{ width: '100%', height: 480, objectFit: 'cover' }} />
            </div>
            <div style={{ position: 'absolute', inset: 'auto auto -14px -14px', width: 120, height: 120, borderBottom: '2px solid #C8602B', borderLeft: '2px solid #C8602B' }} />
          </div>
          <div>
            <div style={{ fontSize: 13, fontWeight: 700, letterSpacing: '.16em', textTransform: 'uppercase' as const, color: '#C8602B', marginBottom: 16 }}>{u.curriculum_eyebrow}</div>
            <h2 style={{ fontFamily: fonts.display, fontWeight: 400, fontSize: 'clamp(32px,5vw,56px)', lineHeight: .96, textTransform: 'uppercase' as const, marginBottom: 28 }}>{u.curriculum_title}</h2>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
              {c.modules.map((m, i) => (
                <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 18, padding: '15px 0', borderBottom: '1px solid rgba(255,255,255,.08)' }}>
                  <span style={{ fontFamily: fonts.display, fontSize: 20, color: '#C8602B', minWidth: 32 }}>{String(i + 1).padStart(2, '0')}</span>
                  <span style={{ fontSize: 16, color: '#D7CFC4' }}>{m.title}</span>
                </div>
              ))}
            </div>
            <Link href={`/${locale}/programme`} style={{ marginTop: 30, display: 'inline-flex', alignItems: 'center', gap: 10, background: '#C8602B', color: '#160F0B', fontWeight: 700, textTransform: 'uppercase' as const, letterSpacing: '.04em', fontSize: 14, padding: '15px 26px', borderRadius: 2 }}>{u.curriculum_cta} →</Link>
          </div>
        </div>
      </section>

      {/* ── GALLERY TEASER ── */}
      <section style={{ background: '#0E0D0C', padding: 'clamp(64px,9vw,110px) 24px' }}>
        <div style={{ maxWidth: 1240, margin: '0 auto' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', flexWrap: 'wrap', gap: 20, marginBottom: 36 }}>
            <div>
              <div style={{ fontSize: 13, fontWeight: 700, letterSpacing: '.16em', textTransform: 'uppercase' as const, color: '#C8602B', marginBottom: 16 }}>{u.gallery_eyebrow}</div>
              <h2 style={{ fontFamily: fonts.display, fontWeight: 400, fontSize: 'clamp(32px,5vw,56px)', lineHeight: .96, textTransform: 'uppercase' as const }}>{u.gallery_title}</h2>
            </div>
            <Link href={`/${locale}/galerie`} style={{ border: '1px solid rgba(255,255,255,.24)', color: '#F4EEE6', fontWeight: 600, textTransform: 'uppercase' as const, letterSpacing: '.03em', fontSize: 13, padding: '13px 22px', borderRadius: 2 }}>{u.cta_view_gallery}</Link>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(180px,1fr))', gap: 12 }}>
            {galleryTeaser.map((src, i) => (
              <Link key={i} href={`/${locale}/galerie`} style={{ display: 'block', overflow: 'hidden', borderRadius: 4, border: '1px solid rgba(255,255,255,.08)', aspectRatio: '1/1.15' }}>
                <img src={src} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ── TESTIMONIALS ── */}
      <section style={{ background: '#120D0A', padding: 'clamp(64px,9vw,120px) 24px', borderBlock: '1px solid rgba(255,255,255,.08)' }}>
        <div style={{ maxWidth: 1100, margin: '0 auto' }}>
          <div style={{ fontSize: 13, fontWeight: 700, letterSpacing: '.16em', textTransform: 'uppercase' as const, color: '#C8602B', marginBottom: 16, textAlign: 'center' }}>{u.testi_eyebrow}</div>
          <h2 style={{ fontFamily: fonts.display, fontWeight: 400, fontSize: 'clamp(32px,5vw,56px)', lineHeight: .96, textTransform: 'uppercase' as const, textAlign: 'center', marginBottom: 48 }}>{u.testi_title}</h2>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(300px,1fr))', gap: 20 }}>
            {c.testimonials.map((ti, i) => (
              <div key={i} style={{ background: '#0E0D0C', border: '1px solid rgba(255,255,255,.08)', borderRadius: 6, padding: '36px 32px' }}>
                <div style={{ fontFamily: fonts.display, fontSize: 54, color: '#C8602B', lineHeight: .6, height: 30 }}>&ldquo;</div>
                <p style={{ fontSize: 19, color: '#E7E0D6', lineHeight: 1.5, marginBottom: 26 }}>{ti.quote}</p>
                <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                  <div style={{ width: 46, height: 46, borderRadius: '50%', background: '#C8602B', color: '#160F0B', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: 15, flexShrink: 0 }}>{ti.initials}</div>
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 15 }}>{ti.name}</div>
                    <div style={{ fontSize: 13, color: '#988F84' }}>{ti.role}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA DUAL ── */}
      <section style={{ background: '#0E0D0C', padding: 'clamp(56px,8vw,100px) 24px' }}>
        <div style={{ maxWidth: 1240, margin: '0 auto', display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(300px,1fr))', gap: 20 }}>
          <div style={{ position: 'relative', overflow: 'hidden', borderRadius: 8, border: '1px solid rgba(255,255,255,.1)', padding: '48px 40px', background: 'linear-gradient(135deg,#1A120C,#0E0D0C)' }}>
            <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(120% 100% at 100% 0%,rgba(200,96,43,.18),transparent 60%)' }} />
            <div style={{ position: 'relative' }}>
              <div style={{ fontSize: 12, fontWeight: 700, letterSpacing: '.14em', textTransform: 'uppercase' as const, color: '#E0A35A', marginBottom: 14 }}>{u.cta_b2c_tag}</div>
              <h3 style={{ fontFamily: fonts.display, fontWeight: 400, fontSize: 'clamp(28px,3.4vw,40px)', textTransform: 'uppercase' as const, lineHeight: 1, marginBottom: 14 }}>{u.cta_b2c_title}</h3>
              <p style={{ color: '#988F84', marginBottom: 26, maxWidth: 380 }}>{u.cta_b2c_sub}</p>
              <Link href={`/${locale}/inscription`} style={{ background: '#C8602B', color: '#160F0B', fontWeight: 700, textTransform: 'uppercase' as const, letterSpacing: '.04em', fontSize: 14, padding: '15px 26px', borderRadius: 2, display: 'inline-block' }}>{u.cta_enroll} →</Link>
            </div>
          </div>
          <div style={{ borderRadius: 8, border: '1px solid rgba(255,255,255,.1)', padding: '48px 40px', background: '#15100C' }}>
            <div style={{ fontSize: 12, fontWeight: 700, letterSpacing: '.14em', textTransform: 'uppercase' as const, color: '#988F84', marginBottom: 14 }}>{u.cta_b2b_tag}</div>
            <h3 style={{ fontFamily: fonts.display, fontWeight: 400, fontSize: 'clamp(28px,3.4vw,40px)', textTransform: 'uppercase' as const, lineHeight: 1, marginBottom: 14 }}>{u.cta_b2b_title}</h3>
            <p style={{ color: '#988F84', marginBottom: 26, maxWidth: 380 }}>{u.cta_b2b_sub}</p>
            <Link href={`/${locale}/contact`} style={{ border: '1px solid rgba(255,255,255,.28)', color: '#F4EEE6', fontWeight: 600, textTransform: 'uppercase' as const, letterSpacing: '.03em', fontSize: 14, padding: '15px 26px', borderRadius: 2, display: 'inline-block' }}>{u.cta_b2b_btn} →</Link>
          </div>
        </div>
      </section>
    </>
  );
}
