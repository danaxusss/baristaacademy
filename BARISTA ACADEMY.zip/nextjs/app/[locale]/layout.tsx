import type { Metadata } from 'next';
import { getContent, getFonts } from '@/lib/content';
import ModalProvider from '@/components/ModalProvider';

export async function generateStaticParams() {
  return [{ locale: 'fr' }, { locale: 'ar' }];
}

export async function generateMetadata({ params }: { params: { locale: string } }): Promise<Metadata> {
  const isAr = params.locale === 'ar';
  return {
    title: isAr
      ? 'أكاديمية الباريستا المغربية — الدار البيضاء'
      : 'Barista Moroccan Academy — Casablanca',
    description: isAr
      ? 'تكوينات الباريستا، اللاتيه آرت والميكسولوجي في الدار البيضاء'
      : 'Formations Barista, Latte Art & Mixologie à Casablanca.',
  };
}

export default function LocaleLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: { locale: string };
}) {
  const { locale } = params;
  const c = getContent(locale);
  const fonts = getFonts(c.dir);

  return (
    <ModalProvider locale={locale} content={c} fonts={fonts}>
      {children}
    </ModalProvider>
  );
}
