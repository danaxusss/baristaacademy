import { getContent, getFonts } from '@/lib/content';
import InscriptionForm from '@/components/InscriptionForm';

export function generateStaticParams() {
  return [{ locale: 'fr' }, { locale: 'ar' }];
}

export default function InscriptionPage({ params }: { params: { locale: string } }) {
  const { locale } = params;
  const c = getContent(locale);
  const u = c.ui;
  const fonts = getFonts(c.dir);

  return (
    <>
      <div style={{ background: '#120D0A', borderBottom: '1px solid rgba(255,255,255,.08)', padding: 'clamp(52px,7vw,86px) 24px clamp(36px,4vw,52px)' }}>
        <div style={{ maxWidth: 1240, margin: '0 auto' }}>
          <div style={{ fontSize: 13, fontWeight: 700, letterSpacing: '.16em', textTransform: 'uppercase' as const, color: '#C8602B', marginBottom: 16 }}>{u.insc_eyebrow}</div>
          <h1 style={{ fontFamily: fonts.display, fontWeight: 400, fontSize: 'clamp(38px,6.5vw,76px)', lineHeight: .94, textTransform: 'uppercase' as const, marginBottom: 18 }}>{u.insc_title}</h1>
          <p style={{ color: '#C9C0B5', fontSize: 18, maxWidth: 600 }}>{u.insc_sub}</p>
        </div>
      </div>

      <section style={{ background: '#0E0D0C', padding: 'clamp(48px,6vw,80px) 24px clamp(64px,9vw,100px)' }}>
        <div style={{ maxWidth: 1180, margin: '0 auto', display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(380px,1fr))', gap: 48, alignItems: 'start' }}>
          {/* Form */}
          <div style={{ background: '#16110D', border: '1px solid rgba(255,255,255,.08)', borderRadius: 8, padding: 'clamp(28px,4vw,40px)' }}>
            <InscriptionForm locale={locale} c={c} fonts={fonts} />
          </div>

          {/* Sidebar */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
            <div style={{ position: 'relative', overflow: 'hidden', borderRadius: 8, border: '1px solid rgba(255,255,255,.1)', minHeight: 230 }}>
              <img src="/assets/photo/p7.jpg" alt="" style={{ width: '100%', height: '100%', objectFit: 'cover', position: 'absolute', inset: 0 }} />
              <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg,rgba(14,13,12,.2),rgba(14,13,12,.85))' }} />
              <div style={{ position: 'relative', padding: 26, display: 'flex', alignItems: 'flex-end', minHeight: 230 }}>
                <div style={{ fontFamily: fonts.display, fontSize: 30, textTransform: 'uppercase' as const, lineHeight: 1 }}>{u.cta_b2c_title}</div>
              </div>
            </div>
            <div style={{ background: '#16110D', border: '1px solid rgba(255,255,255,.08)', borderRadius: 8, padding: 26 }}>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
                <a href="https://wa.me/212657116631" target="_blank" rel="noreferrer" style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                  <span style={{ width: 40, height: 40, borderRadius: 2, background: 'rgba(200,96,43,.16)', color: '#E0A35A', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, flexShrink: 0 }}>✆</span>
                  <div><div style={{ fontSize: 12, color: '#776E64' }}>{u.ci_phone}</div><div style={{ fontWeight: 600 }}>+212 657 116 631</div></div>
                </a>
                <a href="mailto:contact@wedrinks.ma" style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                  <span style={{ width: 40, height: 40, borderRadius: 2, background: 'rgba(200,96,43,.16)', color: '#E0A35A', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, flexShrink: 0 }}>✉</span>
                  <div><div style={{ fontSize: 12, color: '#776E64' }}>{u.ci_email}</div><div style={{ fontWeight: 600 }}>contact@wedrinks.ma</div></div>
                </a>
                <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                  <span style={{ width: 40, height: 40, borderRadius: 2, background: 'rgba(200,96,43,.16)', color: '#E0A35A', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, flexShrink: 0 }}>⚲</span>
                  <div><div style={{ fontSize: 12, color: '#776E64' }}>{u.ci_address}</div><div style={{ fontWeight: 600 }}>{u.footer_address}</div></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
