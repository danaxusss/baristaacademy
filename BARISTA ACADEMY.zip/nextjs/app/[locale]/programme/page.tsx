import Link from 'next/link';
import { getContent, getFonts } from '@/lib/content';
import OpenBookingButton from '@/components/OpenBookingButton';

export function generateStaticParams() {
  return [{ locale: 'fr' }, { locale: 'ar' }];
}

export default function ProgrammePage({ params }: { params: { locale: string } }) {
  const { locale } = params;
  const c = getContent(locale);
  const u = c.ui;
  const fonts = getFonts(c.dir);

  return (
    <>
      {/* Page header */}
      <div style={{ background: '#120D0A', borderBottom: '1px solid rgba(255,255,255,.08)', padding: 'clamp(52px,7vw,86px) 24px clamp(36px,4vw,52px)' }}>
        <div style={{ maxWidth: 1240, margin: '0 auto' }}>
          <div style={{ fontSize: 13, fontWeight: 700, letterSpacing: '.16em', textTransform: 'uppercase' as const, color: '#C8602B', marginBottom: 16 }}>{u.curriculum_eyebrow}</div>
          <h1 style={{ fontFamily: fonts.display, fontWeight: 400, fontSize: 'clamp(38px,6.5vw,76px)', lineHeight: .94, textTransform: 'uppercase' as const, marginBottom: 18 }}>{u.curriculum_title}</h1>
          <p style={{ color: '#C9C0B5', fontSize: 18, maxWidth: 640 }}>{u.prog_intro}</p>
        </div>
      </div>

      {/* Modules */}
      <section style={{ background: '#0E0D0C', padding: 'clamp(56px,8vw,96px) 24px' }}>
        <div style={{ maxWidth: 900, margin: '0 auto', display: 'flex', flexDirection: 'column' }}>
          {c.modules.map((m, i) => (
            <div key={i} style={{ display: 'flex', gap: 24, alignItems: 'flex-start', padding: '32px 0', borderBottom: '1px solid rgba(255,255,255,.08)' }}>
              <div style={{ fontFamily: fonts.display, fontSize: 'clamp(36px,5vw,56px)', color: '#C8602B', lineHeight: .85, minWidth: 74 }}>{String(i + 1).padStart(2, '0')}</div>
              <div style={{ paddingTop: 4, flex: 1 }}>
                <h3 style={{ fontFamily: fonts.display, fontWeight: 400, fontSize: 'clamp(22px,3vw,30px)', textTransform: 'uppercase' as const, lineHeight: 1.02, marginBottom: 8 }}>{m.title}</h3>
                <p style={{ color: '#988F84', fontSize: 15.5, maxWidth: 620, marginBottom: 18 }}>{m.desc}</p>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(240px,1fr))', gap: '15px 24px' }}>
                  {m.points.map((pt, j) => (
                    <div key={j} style={{ display: 'flex', gap: 10, alignItems: 'flex-start', fontSize: 14.5, lineHeight: 1.35, color: '#C9C0B5' }}>
                      <span style={{ color: '#C8602B', fontWeight: 700, flexShrink: 0 }}>✓</span><span>{pt}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Sessions */}
      <section style={{ background: '#120D0A', padding: 'clamp(56px,8vw,96px) 24px', borderBlock: '1px solid rgba(255,255,255,.08)' }}>
        <div style={{ maxWidth: 1240, margin: '0 auto' }}>
          <h2 style={{ fontFamily: fonts.display, fontWeight: 400, fontSize: 'clamp(28px,4vw,46px)', textTransform: 'uppercase' as const, marginBottom: 36 }}>{u.sessions_title}</h2>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(260px,1fr))', gap: 18 }}>
            {c.sessions.map((s, i) => (
              <div key={i} style={{ background: '#0E0D0C', border: '1px solid rgba(255,255,255,.08)', borderRadius: 6, padding: '30px 28px' }}>
                <div style={{ width: 40, height: 3, background: '#C8602B', marginBottom: 20 }} />
                <h3 style={{ fontFamily: fonts.display, fontWeight: 400, fontSize: 24, textTransform: 'uppercase' as const, marginBottom: 12, lineHeight: 1.05 }}>{s.title}</h3>
                <p style={{ color: '#988F84', fontSize: 15 }}>{s.desc}</p>
              </div>
            ))}
          </div>
          <div style={{ marginTop: 36, display: 'flex', gap: 14, flexWrap: 'wrap' }}>
            <Link href={`/${locale}/inscription`} style={{ display: 'inline-flex', alignItems: 'center', gap: 10, background: '#C8602B', color: '#160F0B', fontWeight: 700, textTransform: 'uppercase' as const, letterSpacing: '.04em', fontSize: 15, padding: '16px 28px', borderRadius: 2 }}>{u.choose_session} →</Link>
            <OpenBookingButton
              label={u.cta_book}
              style={{ border: '1px solid rgba(255,255,255,.28)', color: '#F4EEE6', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '.03em', fontSize: 15, padding: '16px 28px', borderRadius: 2, cursor: 'pointer' }}
            />
          </div>
        </div>
      </section>
    </>
  );
}
