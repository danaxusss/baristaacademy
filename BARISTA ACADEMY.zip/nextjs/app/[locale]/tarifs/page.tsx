import Link from 'next/link';
import { getContent, getFonts } from '@/lib/content';

export function generateStaticParams() {
  return [{ locale: 'fr' }, { locale: 'ar' }];
}

export default function TarifsPage({ params }: { params: { locale: string } }) {
  const { locale } = params;
  const c = getContent(locale);
  const u = c.ui;
  const fonts = getFonts(c.dir);

  return (
    <>
      <div style={{ background: '#120D0A', borderBottom: '1px solid rgba(255,255,255,.08)', padding: 'clamp(52px,7vw,86px) 24px clamp(36px,4vw,52px)' }}>
        <div style={{ maxWidth: 1240, margin: '0 auto' }}>
          <div style={{ fontSize: 13, fontWeight: 700, letterSpacing: '.16em', textTransform: 'uppercase' as const, color: '#C8602B', marginBottom: 16 }}>{u.tarifs_eyebrow}</div>
          <h1 style={{ fontFamily: fonts.display, fontWeight: 400, fontSize: 'clamp(38px,6.5vw,76px)', lineHeight: .94, textTransform: 'uppercase' as const, marginBottom: 18 }}>{u.tarifs_title}</h1>
          <p style={{ color: '#C9C0B5', fontSize: 18, maxWidth: 600 }}>{u.tarifs_sub}</p>
        </div>
      </div>

      <section style={{ background: '#0E0D0C', padding: 'clamp(48px,6vw,80px) 24px clamp(56px,8vw,100px)' }}>
        <div style={{ maxWidth: 1180, margin: '0 auto' }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(290px,1fr))', gap: 20, alignItems: 'stretch' }}>
            {c.programs.map(p => (
              <div key={p.key} style={{ background: '#16110D', border: `1px solid ${p.featured ? 'rgba(200,96,43,.5)' : 'rgba(255,255,255,.08)'}`, borderRadius: 7, display: 'flex' }}>
                <div style={{ padding: '32px 30px 30px', display: 'flex', flexDirection: 'column', width: '100%' }}>
                  {p.featured && <div style={{ alignSelf: 'flex-start', background: '#C8602B', color: '#160F0B', fontSize: 11, fontWeight: 700, letterSpacing: '.1em', textTransform: 'uppercase' as const, padding: '6px 11px', borderRadius: 2, marginBottom: 18, whiteSpace: 'nowrap' }}>{u.featured}</div>}
                  <h3 style={{ fontFamily: fonts.display, fontWeight: 400, fontSize: 28, textTransform: 'uppercase' as const, lineHeight: 1, marginBottom: 6 }}>{p.name}</h3>
                  <div style={{ fontSize: 13, color: '#988F84', marginBottom: 22 }}>{p.levelLabel} · {p.dur}</div>
                  <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, paddingBottom: 24, borderBottom: '1px solid rgba(255,255,255,.08)', marginBottom: 24 }}>
                    <div dir="ltr" style={{ fontFamily: fonts.display, fontSize: 46, color: '#E0A35A', lineHeight: .9, whiteSpace: 'nowrap' }}>{p.price}</div>
                    <div dir="ltr" style={{ fontSize: 13, color: '#776E64' }}>{p.priceNote}</div>
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 12, marginBottom: 28 }}>
                    {p.points.map((pt, i) => (
                      <div key={i} style={{ display: 'flex', gap: 11, alignItems: 'flex-start', fontSize: 14.5, lineHeight: 1.35, color: '#D7CFC4' }}>
                        <span style={{ color: '#C8602B', fontWeight: 700, flexShrink: 0 }}>✓</span><span>{pt}</span>
                      </div>
                    ))}
                  </div>
                  <Link href={`/${locale}/inscription`} style={{ marginTop: 'auto', width: '100%', background: '#C8602B', color: '#160F0B', fontWeight: 700, textTransform: 'uppercase' as const, letterSpacing: '.04em', fontSize: 14, padding: 15, borderRadius: 2, textAlign: 'center' as const, display: 'block' }}>{u.cta_enroll}</Link>
                </div>
              </div>
            ))}
          </div>
          <div style={{ marginTop: 28, display: 'flex', gap: 14, alignItems: 'flex-start', background: '#15100C', border: '1px solid rgba(255,255,255,.08)', borderRadius: 6, padding: '22px 24px' }}>
            <span style={{ color: '#E0A35A', fontSize: 20, flexShrink: 0 }}>ⓘ</span>
            <p style={{ color: '#988F84', fontSize: 14.5, lineHeight: 1.55 }}>{u.tarifs_note}</p>
          </div>
        </div>
      </section>
    </>
  );
}
