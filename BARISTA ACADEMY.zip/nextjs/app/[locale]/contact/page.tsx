import { getContent, getFonts } from '@/lib/content';
import ContactForm from '@/components/ContactForm';

export function generateStaticParams() {
  return [{ locale: 'fr' }, { locale: 'ar' }];
}

export default function ContactPage({ params }: { params: { locale: string } }) {
  const { locale } = params;
  const c = getContent(locale);
  const u = c.ui;
  const fonts = getFonts(c.dir);

  return (
    <>
      <div style={{ background: '#120D0A', borderBottom: '1px solid rgba(255,255,255,.08)', padding: 'clamp(52px,7vw,86px) 24px clamp(36px,4vw,52px)' }}>
        <div style={{ maxWidth: 1240, margin: '0 auto' }}>
          <div style={{ fontSize: 13, fontWeight: 700, letterSpacing: '.16em', textTransform: 'uppercase' as const, color: '#C8602B', marginBottom: 16 }}>{u.contact_eyebrow}</div>
          <h1 style={{ fontFamily: fonts.display, fontWeight: 400, fontSize: 'clamp(38px,6.5vw,76px)', lineHeight: .94, textTransform: 'uppercase' as const, marginBottom: 18 }}>{u.contact_title}</h1>
          <p style={{ color: '#C9C0B5', fontSize: 18, maxWidth: 600 }}>{u.contact_sub}</p>
        </div>
      </div>

      <section style={{ background: '#0E0D0C', padding: 'clamp(48px,6vw,80px) 24px clamp(64px,9vw,100px)' }}>
        <div style={{ maxWidth: 1180, margin: '0 auto', display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(380px,1fr))', gap: 48, alignItems: 'start' }}>
          {/* Form card */}
          <div style={{ background: '#16110D', border: '1px solid rgba(255,255,255,.08)', borderRadius: 8, padding: 'clamp(28px,4vw,40px)' }}>
            <h3 style={{ fontFamily: fonts.display, fontWeight: 400, fontSize: 24, textTransform: 'uppercase' as const, marginBottom: 22 }}>{u.contact_form_title}</h3>
            <ContactForm locale={locale} c={c} fonts={fonts} />
          </div>

          {/* Contact info sidebar */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <div style={{ background: '#16110D', border: '1px solid rgba(255,255,255,.08)', borderRadius: 8, padding: 28, display: 'flex', flexDirection: 'column', gap: 18 }}>
              {[
                { icon: '✆', label: u.ci_phone, val: '+212 657 116 631', href: 'https://wa.me/212657116631' },
                { icon: '✉', label: u.ci_email, val: 'contact@wedrinks.ma', href: 'mailto:contact@wedrinks.ma' },
                { icon: '⚲', label: u.ci_address, val: u.footer_address },
                { icon: '◷', label: u.ci_hours, val: u.hours_val },
              ].map((item, i) => (
                <div key={i}>
                  {item.href ? (
                    <a href={item.href} target={item.href.startsWith('http') ? '_blank' : undefined} rel="noreferrer" style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                      <span style={{ width: 42, height: 42, borderRadius: 2, background: 'rgba(200,96,43,.16)', color: '#E0A35A', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, flexShrink: 0 }}>{item.icon}</span>
                      <div><div style={{ fontSize: 12, color: '#776E64' }}>{item.label}</div><div style={{ fontWeight: 600 }}>{item.val}</div></div>
                    </a>
                  ) : (
                    <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                      <span style={{ width: 42, height: 42, borderRadius: 2, background: 'rgba(200,96,43,.16)', color: '#E0A35A', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, flexShrink: 0 }}>{item.icon}</span>
                      <div><div style={{ fontSize: 12, color: '#776E64' }}>{item.label}</div><div style={{ fontWeight: 600 }}>{item.val}</div></div>
                    </div>
                  )}
                </div>
              ))}
            </div>
            <div style={{ position: 'relative', overflow: 'hidden', borderRadius: 8, border: '1px solid rgba(255,255,255,.1)', minHeight: 220, background: '#0A0908' }}>
              <img src="/assets/photo/p6.jpg" alt="" style={{ width: '100%', height: '100%', objectFit: 'cover', position: 'absolute', inset: 0, opacity: .5 }} />
              <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle at 50% 45%,transparent,rgba(10,9,8,.9))' }} />
              <div style={{ position: 'relative', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: 220, textAlign: 'center', padding: 24 }}>
                <span style={{ color: '#C8602B', fontSize: 34, marginBottom: 10 }}>⚲</span>
                <div style={{ fontFamily: fonts.display, fontSize: 22, textTransform: 'uppercase' as const }}>{u.map_label}</div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
