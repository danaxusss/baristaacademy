import Link from 'next/link';
import { notFound } from 'next/navigation';
import { getContent, getFonts } from '@/lib/content';

export function generateStaticParams() {
  return ['fr', 'ar'].flatMap(locale =>
    getContent(locale).posts.map(post => ({ locale, slug: post.slug }))
  );
}

export default function BlogPostPage({ params }: { params: { locale: string; slug: string } }) {
  const { locale, slug } = params;
  const c = getContent(locale);
  const u = c.ui;
  const fonts = getFonts(c.dir);
  const post = c.posts.find(p => p.slug === slug);
  if (!post) notFound();

  return (
    <article style={{ background: '#0E0D0C' }}>
      <div style={{ maxWidth: 780, margin: '0 auto', padding: 'clamp(40px,6vw,72px) 24px 0' }}>
        <Link href={`/${locale}/blog`} style={{ color: '#988F84', fontSize: 14, fontWeight: 600, marginBottom: 28, display: 'inline-block' }}>
          {u.blog_back}
        </Link>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18 }}>
          <span style={{ background: 'rgba(224,163,90,.14)', border: '1px solid rgba(224,163,90,.4)', color: '#E0A35A', fontSize: 11, fontWeight: 700, letterSpacing: '.08em', textTransform: 'uppercase' as const, padding: '5px 10px', borderRadius: 2 }}>{post.cat}</span>
          <span style={{ fontSize: 13, color: '#776E64' }}>{post.date}</span>
        </div>
        <h1 style={{ fontFamily: fonts.display, fontWeight: 400, fontSize: 'clamp(32px,5.5vw,58px)', lineHeight: 1, textTransform: 'uppercase' as const, marginBottom: 30 }}>{post.title}</h1>
      </div>

      <div style={{ maxWidth: 980, margin: '0 auto', padding: '0 24px' }}>
        <div style={{ overflow: 'hidden', borderRadius: 8, border: '1px solid rgba(255,255,255,.1)' }}>
          <img src={post.img} alt="" style={{ width: '100%', height: 'clamp(240px,42vw,460px)', objectFit: 'cover' }} />
        </div>
      </div>

      <div style={{ maxWidth: 780, margin: '0 auto', padding: 'clamp(36px,5vw,52px) 24px clamp(56px,8vw,90px)', display: 'flex', flexDirection: 'column', gap: 22 }}>
        {post.body.map((para, i) => (
          <p key={i} style={{ fontSize: 18, lineHeight: 1.7, color: '#C9C0B5' }}>{para}</p>
        ))}
        <div style={{ marginTop: 24, display: 'flex', gap: 14, flexWrap: 'wrap', borderTop: '1px solid rgba(255,255,255,.08)', paddingTop: 32 }}>
          <Link href={`/${locale}/inscription`} style={{ background: '#C8602B', color: '#160F0B', fontWeight: 700, textTransform: 'uppercase' as const, letterSpacing: '.04em', fontSize: 14, padding: '15px 26px', borderRadius: 2, display: 'inline-block' }}>{u.cta_enroll} →</Link>
          <Link href={`/${locale}/blog`} style={{ border: '1px solid rgba(255,255,255,.24)', color: '#F4EEE6', fontWeight: 600, textTransform: 'uppercase' as const, letterSpacing: '.03em', fontSize: 14, padding: '15px 26px', borderRadius: 2, display: 'inline-block' }}>{u.blog_all}</Link>
        </div>
      </div>
    </article>
  );
}
