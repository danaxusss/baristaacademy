import Link from 'next/link';
import { getContent, getFonts } from '@/lib/content';

export function generateStaticParams() {
  return [{ locale: 'fr' }, { locale: 'ar' }];
}

export default function BlogPage({ params }: { params: { locale: string } }) {
  const { locale } = params;
  const c = getContent(locale);
  const u = c.ui;
  const fonts = getFonts(c.dir);

  return (
    <>
      <div style={{ background: '#120D0A', borderBottom: '1px solid rgba(255,255,255,.08)', padding: 'clamp(52px,7vw,86px) 24px clamp(36px,4vw,52px)' }}>
        <div style={{ maxWidth: 1240, margin: '0 auto' }}>
          <div style={{ fontSize: 13, fontWeight: 700, letterSpacing: '.16em', textTransform: 'uppercase' as const, color: '#C8602B', marginBottom: 16 }}>{u.blog_eyebrow}</div>
          <h1 style={{ fontFamily: fonts.display, fontWeight: 400, fontSize: 'clamp(38px,6.5vw,76px)', lineHeight: .94, textTransform: 'uppercase' as const, marginBottom: 18 }}>{u.blog_title}</h1>
          <p style={{ color: '#C9C0B5', fontSize: 18, maxWidth: 600 }}>{u.blog_sub}</p>
        </div>
      </div>

      <section style={{ background: '#0E0D0C', padding: 'clamp(48px,6vw,80px) 24px clamp(64px,9vw,110px)' }}>
        <div style={{ maxWidth: 1240, margin: '0 auto' }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(310px,1fr))', gap: 22 }}>
            {c.posts.map(post => (
              <Link key={post.slug} href={`/${locale}/blog/${post.slug}`} style={{ textAlign: 'start', background: '#16110D', border: '1px solid rgba(255,255,255,.08)', borderRadius: 7, overflow: 'hidden', display: 'flex', flexDirection: 'column', transition: 'transform .3s,border-color .3s' }}>
                <div style={{ position: 'relative', height: 200, overflow: 'hidden' }}>
                  <img src={post.img} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                  <div style={{ position: 'absolute', top: 12, insetInlineStart: 12, background: 'rgba(14,13,12,.85)', border: '1px solid rgba(224,163,90,.4)', color: '#E0A35A', fontSize: 11, fontWeight: 700, letterSpacing: '.08em', textTransform: 'uppercase' as const, padding: '5px 10px', borderRadius: 2 }}>{post.cat}</div>
                </div>
                <div style={{ padding: '24px 24px 26px', display: 'flex', flexDirection: 'column', flex: 1 }}>
                  <div style={{ fontSize: 12.5, color: '#776E64', marginBottom: 12 }}>{post.date}</div>
                  <h3 style={{ fontFamily: fonts.display, fontWeight: 400, fontSize: 23, textTransform: 'uppercase' as const, lineHeight: 1.05, marginBottom: 12 }}>{post.title}</h3>
                  <p style={{ color: '#988F84', fontSize: 14.5, marginBottom: 18 }}>{post.excerpt}</p>
                  <span style={{ marginTop: 'auto', color: '#E0A35A', fontWeight: 700, textTransform: 'uppercase' as const, letterSpacing: '.04em', fontSize: 13 }}>{u.blog_read} →</span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
