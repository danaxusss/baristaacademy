import { getContent, getFonts } from '@/lib/content';
import FormationsGrid from '@/components/FormationsGrid';

export function generateStaticParams() {
  return [{ locale: 'fr' }, { locale: 'ar' }];
}

export default function FormationsPage({ params }: { params: { locale: string } }) {
  const { locale } = params;
  const c = getContent(locale);
  const u = c.ui;
  const fonts = getFonts(c.dir);

  return (
    <>
      {/* Page header */}
      <div style={{ background: '#120D0A', borderBottom: '1px solid rgba(255,255,255,.08)', padding: 'clamp(52px,7vw,86px) 24px clamp(36px,4vw,52px)' }}>
        <div style={{ maxWidth: 1240, margin: '0 auto' }}>
          <div style={{ fontSize: 13, fontWeight: 700, letterSpacing: '.16em', textTransform: 'uppercase' as const, color: '#C8602B', marginBottom: 16 }}>{u.programs_eyebrow}</div>
          <h1 style={{ fontFamily: fonts.display, fontWeight: 400, fontSize: 'clamp(38px,6.5vw,76px)', lineHeight: .94, textTransform: 'uppercase' as const, marginBottom: 18 }}>{u.programs_title}</h1>
          <p style={{ color: '#C9C0B5', fontSize: 18, maxWidth: 620 }}>{u.formations_sub}</p>
        </div>
      </div>

      {/* Grid with filter */}
      <section style={{ background: '#0E0D0C', padding: 'clamp(40px,5vw,60px) 24px clamp(64px,9vw,110px)' }}>
        <div style={{ maxWidth: 1240, margin: '0 auto' }}>
          <FormationsGrid
            programs={c.programs}
            filters={c.filters}
            locale={locale}
            ui={c.ui}
            fonts={fonts}
          />
        </div>
      </section>
    </>
  );
}
