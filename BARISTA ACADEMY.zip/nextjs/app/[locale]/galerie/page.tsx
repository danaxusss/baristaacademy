import { getContent, getFonts } from '@/lib/content';
import GalleryGrid from '@/components/GalleryGrid';

export function generateStaticParams() {
  return [{ locale: 'fr' }, { locale: 'ar' }];
}

export default function GaleriePage({ params }: { params: { locale: string } }) {
  const { locale } = params;
  const c = getContent(locale);
  const u = c.ui;
  const fonts = getFonts(c.dir);

  return (
    <>
      <div style={{ background: '#120D0A', borderBottom: '1px solid rgba(255,255,255,.08)', padding: 'clamp(52px,7vw,86px) 24px clamp(36px,4vw,52px)' }}>
        <div style={{ maxWidth: 1240, margin: '0 auto' }}>
          <div style={{ fontSize: 13, fontWeight: 700, letterSpacing: '.16em', textTransform: 'uppercase' as const, color: '#C8602B', marginBottom: 16 }}>{u.gallery_eyebrow}</div>
          <h1 style={{ fontFamily: fonts.display, fontWeight: 400, fontSize: 'clamp(38px,6.5vw,76px)', lineHeight: .94, textTransform: 'uppercase' as const }}>{u.gallery_title}</h1>
        </div>
      </div>
      <section style={{ background: '#0E0D0C', padding: 'clamp(36px,5vw,56px) 24px clamp(64px,9vw,110px)' }}>
        <div style={{ maxWidth: 1240, margin: '0 auto' }}>
          <GalleryGrid
            galleryCats={c.galleryCats}
            certTitle={u.galerie_cert_title}
            certSub={u.galerie_cert_sub}
          />
        </div>
      </section>
    </>
  );
}
