# Barista Moroccan Academy — Next.js 14

**Stack**: Next.js 14 App Router · TypeScript · Tailwind CSS · Bilingual (FR + AR / RTL)

---

## Quick Start

```bash
npm install
npm run dev
# → http://localhost:3000  (redirects to /fr)
```

---

## Project Structure

```
app/
  [locale]/          # fr | ar
    page.tsx         # Home
    formations/      # Program listing (filter)
    programme/       # 3-module curriculum
    tarifs/          # Pricing cards
    galerie/         # Photo gallery (filter)
    inscription/     # Lead capture form
    faq/             # FAQ accordion
    contact/         # Contact form + map
    blog/
      page.tsx       # Article listing
      [slug]/        # Individual post

components/
  ModalProvider.tsx  # Context — booking modal + Header/Footer wrapper
  Header.tsx         # Sticky nav, language switcher, mobile menu
  Footer.tsx         # Links, contact, newsletter
  BookingModal.tsx   # Booking form overlay
  FormationsGrid.tsx # Filter + program cards
  GalleryGrid.tsx    # Filter + photo grid
  FaqAccordion.tsx   # Accordion
  InscriptionForm.tsx
  ContactForm.tsx
  NewsletterForm.tsx
  OpenBookingButton.tsx

lib/
  content.ts         # All FR + AR content (programs, modules, FAQs, posts…)
  config.ts          # Locales, nav constants
```

---

## Copy Your Assets

Place these in `public/` (create the folder if missing):

```
public/
  assets/
    logo-wedrinks-tv.png
    logo-shield-white.png
    photo/
      p1.jpg … p9.jpg
```

These are the files from the original project's `assets/` folder.

---

## Adding Content

All content lives in **`lib/content.ts`**. Edit the `fr` and `ar` objects to update:
- Programs (prices, descriptions, bullet points)
- Modules
- FAQs
- Blog posts
- Stats, testimonials, sessions

---

## Deployment (Vercel)

```bash
# 1. Push to GitHub
git add .
git commit -m "Next.js site"
git push

# 2. Import in Vercel
# → vercel.com → New Project → Import danaxusss/baristaacademy
# → Framework: Next.js (auto-detected)
# → No env vars needed for base site
# → Deploy
```

### Environment variables (future phases)
```
SENDGRID_API_KEY=...       # Phase 4 — email notifications
NEXT_PUBLIC_GA_ID=...      # Optional analytics
```

---

## Adding Email Notifications (Phase 4)

Create `app/api/contact/route.ts`:

```ts
import { NextResponse } from 'next/server';

export async function POST(req: Request) {
  const body = await req.json();
  // Send via SendGrid / Resend here
  // await sendEmail({ to: 'contact@wedrinks.ma', subject: '...', ...body });
  return NextResponse.json({ ok: true });
}
```

Then call `/api/contact` from `ContactForm.tsx` and `InscriptionForm.tsx` on submit.

---

## Language URLs

| URL | Page |
|-----|------|
| `/fr` | Home (French) |
| `/ar` | Home (Arabic, RTL) |
| `/fr/formations` | Programs (FR) |
| `/ar/formations` | Programs (AR) |
| `/fr/blog/extraction-espresso` | Blog post (FR) |

Language switcher in the header swaps `/fr/` ↔ `/ar/` in the current URL.
