'use client';
import { useState } from 'react';
import { usePathname } from 'next/navigation';
import Link from 'next/link';
import type { LocaleContent } from '@/lib/content';

const NAV_PAGES = ['formations', 'programme', 'tarifs', 'galerie', 'blog', 'faq', 'contact'] as const;

interface Props {
  locale: string;
  c: LocaleContent;
  fonts: { display: string; body: string };
  onOpenBooking: () => void;
}

export default function Header({ locale, c, fonts, onOpenBooking }: Props) {
  const [open, setOpen] = useState(false);
  const pathname = usePathname();
  const u = c.ui;
  const isRTL = c.dir === 'rtl';

  const link = (page: string) => page === 'home' ? `/${locale}` : `/${locale}/${page}`;
  const switchTo = (lng: string) => pathname.replace(`/${locale}`, `/${lng}`);
  const isActive = (page: string) =>
    page === 'home'
      ? pathname === `/${locale}` || pathname === `/${locale}/`
      : pathname.startsWith(`/${locale}/${page}`);

  const navLinkStyle = (page: string): React.CSSProperties => ({
    color: isActive(page) ? '#E0A35A' : '#C9C0B5',
    fontSize: 14.5,
    fontWeight: isActive(page) ? 700 : 500,
    letterSpacing: '.01em',
    cursor: 'pointer',
    transition: 'color .2s',
    whiteSpace: 'nowrap',
  });

  return (
    <>
      <header
        className="header-blur"
        style={{ position: 'sticky', top: 0, zIndex: 50, borderBottom: '1px solid rgba(255,255,255,.08)' }}
      >
        <div style={{ maxWidth: 1240, margin: '0 auto', padding: '14px 24px', display: 'flex', alignItems: 'center', gap: 24, justifyContent: 'space-between' }}>
          {/* Logo */}
          <Link href={`/${locale}`} style={{ display: 'flex', alignItems: 'center', flexShrink: 0 }}>
            <img src="/assets/logo-wedrinks-tv.png" alt="Barista Moroccan Academy" style={{ height: 72, width: 'auto', objectFit: 'contain' }} />
          </Link>

          {/* Desktop Nav */}
          <nav style={{ display: 'flex', alignItems: 'center', gap: 26, flexWrap: 'wrap', justifyContent: 'center' }} className="hidden md:flex">
            {NAV_PAGES.map(page => (
              <Link key={page} href={link(page)} style={navLinkStyle(page)}>
                {c.nav[page]}
              </Link>
            ))}
          </nav>

          {/* Right controls */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 14, flexShrink: 0 }}>
            {/* Lang switcher */}
            <div style={{ display: 'flex', alignItems: 'center', border: '1px solid rgba(255,255,255,.16)', borderRadius: 2, overflow: 'hidden' }}>
              <Link href={switchTo('fr')} style={{ padding: '9px 13px', fontSize: 13, fontWeight: 700, background: locale === 'fr' ? '#C8602B' : 'transparent', color: locale === 'fr' ? '#160F0B' : '#C9C0B5', letterSpacing: '.02em' }}>FR</Link>
              <Link href={switchTo('ar')} style={{ padding: '9px 13px', fontSize: 13, fontWeight: 700, background: locale === 'ar' ? '#C8602B' : 'transparent', color: locale === 'ar' ? '#160F0B' : '#C9C0B5', letterSpacing: '.02em' }}>عربي</Link>
            </div>

            {/* Enroll CTA (desktop) */}
            <Link href={`/${locale}/inscription`} className="hidden md:inline-flex" style={{ alignItems: 'center', gap: 8, background: '#C8602B', color: '#160F0B', fontWeight: 700, fontSize: 14, letterSpacing: '.04em', textTransform: 'uppercase', padding: '11px 18px', borderRadius: 2, whiteSpace: 'nowrap' }}>
              {u.cta_enroll}
            </Link>

            {/* Burger */}
            <button onClick={() => setOpen(true)} aria-label="Menu" className="flex md:hidden" style={{ width: 44, height: 44, alignItems: 'center', justifyContent: 'center', border: '1px solid rgba(255,255,255,.16)', borderRadius: 2 }}>
              <div style={{ width: 20, height: 2, background: '#F4EEE6', boxShadow: '0 6px 0 #F4EEE6,0 -6px 0 #F4EEE6' }} />
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Nav Overlay */}
      {open && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 60, background: 'rgba(8,7,6,.97)', backdropFilter: 'blur(8px)', display: 'flex', flexDirection: 'column', padding: 24 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 32 }}>
            <img src="/assets/logo-wedrinks-tv.png" alt="" style={{ height: 64, width: 'auto', objectFit: 'contain' }} />
            <button onClick={() => setOpen(false)} style={{ width: 44, height: 44, border: '1px solid rgba(255,255,255,.16)', borderRadius: 2, color: '#F4EEE6', fontSize: 24 }}>✕</button>
          </div>
          <nav style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
            {NAV_PAGES.map(page => (
              <Link key={page} href={link(page)} onClick={() => setOpen(false)} style={{ fontFamily: fonts.display, fontSize: 30, textTransform: 'uppercase', letterSpacing: '.01em', padding: '10px 0', borderBottom: '1px solid rgba(255,255,255,.07)', color: isActive(page) ? '#E0A35A' : '#F4EEE6' }}>
                {c.nav[page]}
              </Link>
            ))}
          </nav>
          <Link href={`/${locale}/inscription`} onClick={() => setOpen(false)} style={{ marginTop: 28, background: '#C8602B', color: '#160F0B', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.04em', padding: 16, borderRadius: 2, fontSize: 16, textAlign: 'center', display: 'block' }}>
            {u.cta_enroll}
          </Link>
          <a href="https://wa.me/212657116631" target="_blank" rel="noreferrer" style={{ marginTop: 12, textAlign: 'center', border: '1px solid rgba(255,255,255,.18)', padding: 15, borderRadius: 2, color: '#F4EEE6', display: 'block' }}>
            {u.cta_whatsapp} · +212 657 116 631
          </a>
        </div>
      )}
    </>
  );
}
