'use client';
import { useState, FormEvent } from 'react';
import type { LocaleContent } from '@/lib/content';

interface Props { locale: string; c: LocaleContent; fonts: { display: string; body: string }; }

export default function InscriptionForm({ locale, c, fonts }: Props) {
  const u = c.ui;
  const [fields, setFields] = useState({ name: '', email: '', phone: '', program: c.programs[0].key, level: '', date: '', goals: '' });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [sent, setSent] = useState(false);

  const set = (k: string, v: string) => { setFields(f => ({ ...f, [k]: v })); setErrors(e => ({ ...e, [k]: '' })); };

  const validate = () => {
    const e: Record<string, string> = {};
    if (!fields.name.trim()) e.name = u.err_required;
    if (!fields.email.trim()) e.email = u.err_required;
    else if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(fields.email)) e.email = u.err_email;
    if (!fields.phone.trim()) e.phone = u.err_required;
    else if (!/[0-9]{6,}/.test(fields.phone.replace(/\s/g, ''))) e.phone = u.err_phone;
    return e;
  };

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length) { setErrors(errs); return; }
    setSent(true);
  };

  const progName = c.programs.find(p => p.key === fields.program)?.name ?? fields.program;
  const waText = locale === 'ar'
    ? `مرحباً، أرغب في التسجيل في أكاديمية الباريستا.%0Aالاسم: ${fields.name}%0Aالهاتف: ${fields.phone}%0Aالتكوين: ${progName}`
    : `Bonjour, je souhaite m'inscrire à Barista Moroccan Academy.%0ANom: ${fields.name}%0ATéléphone: ${fields.phone}%0AFormation: ${progName}`;
  const waLink = `https://wa.me/212657116631?text=${waText}`;

  const inp = (k: string): React.CSSProperties => ({ width: '100%', background: '#100C09', border: `1px solid ${errors[k] ? '#7a3a2a' : 'rgba(255,255,255,.14)'}`, color: '#F4EEE6', padding: '13px 14px', borderRadius: 3, fontSize: 15, outline: 'none' });

  const levelOptions = locale === 'ar'
    ? [{ v: '', l: '— اختر —' }, { v: 'debutant', l: 'مبتدئ' }, { v: 'intermediaire', l: 'متوسط' }]
    : [{ v: '', l: '— Choisir —' }, { v: 'debutant', l: 'Débutant' }, { v: 'intermediaire', l: 'Intermédiaire' }];

  if (sent) return (
    <div style={{ textAlign: 'center', padding: '30px 10px' }}>
      <div style={{ width: 64, height: 64, borderRadius: '50%', background: 'rgba(224,163,90,.15)', border: '1px solid rgba(224,163,90,.45)', color: '#E0A35A', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 30, margin: '0 auto 20px' }}>✓</div>
      <h3 style={{ fontFamily: fonts.display, fontWeight: 400, fontSize: 26, textTransform: 'uppercase', marginBottom: 10 }}>{u.form_ok_title}</h3>
      <p style={{ color: '#988F84', marginBottom: 26 }}>{u.form_ok_sub}</p>
      <a href={waLink} target="_blank" rel="noreferrer" style={{ display: 'inline-flex', alignItems: 'center', gap: 10, background: '#C8602B', color: '#160F0B', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.04em', fontSize: 14, padding: '15px 26px', borderRadius: 2 }}>{u.cta_whatsapp} →</a>
    </div>
  );

  return (
    <form onSubmit={onSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
      <div>
        <label style={{ display: 'block', fontSize: 13, color: '#988F84', marginBottom: 7, fontWeight: 600 }}>{u.f_name}</label>
        <input value={fields.name} onChange={e => set('name', e.target.value)} style={inp('name')} />
        {errors.name && <div style={{ color: '#E07A5A', fontSize: 12.5, marginTop: 5 }}>{errors.name}</div>}
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
        <div>
          <label style={{ display: 'block', fontSize: 13, color: '#988F84', marginBottom: 7, fontWeight: 600 }}>{u.f_email}</label>
          <input type="email" value={fields.email} onChange={e => set('email', e.target.value)} style={inp('email')} />
          {errors.email && <div style={{ color: '#E07A5A', fontSize: 12.5, marginTop: 5 }}>{errors.email}</div>}
        </div>
        <div>
          <label style={{ display: 'block', fontSize: 13, color: '#988F84', marginBottom: 7, fontWeight: 600 }}>{u.f_phone}</label>
          <input value={fields.phone} onChange={e => set('phone', e.target.value)} placeholder="+212 6.. .. .. .." style={inp('phone')} />
          {errors.phone && <div style={{ color: '#E07A5A', fontSize: 12.5, marginTop: 5 }}>{errors.phone}</div>}
        </div>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
        <div>
          <label style={{ display: 'block', fontSize: 13, color: '#988F84', marginBottom: 7, fontWeight: 600 }}>{u.f_program}</label>
          <select value={fields.program} onChange={e => set('program', e.target.value)} style={{ ...inp('program'), appearance: 'none' as const }}>
            {c.programs.map(p => <option key={p.key} value={p.key}>{p.name} — {p.dur}</option>)}
          </select>
        </div>
        <div>
          <label style={{ display: 'block', fontSize: 13, color: '#988F84', marginBottom: 7, fontWeight: 600 }}>{u.f_level}</label>
          <select value={fields.level} onChange={e => set('level', e.target.value)} style={{ ...inp('level'), appearance: 'none' as const }}>
            {levelOptions.map(o => <option key={o.v} value={o.v}>{o.l}</option>)}
          </select>
        </div>
      </div>
      <div>
        <label style={{ display: 'block', fontSize: 13, color: '#988F84', marginBottom: 7, fontWeight: 600 }}>{u.f_date}</label>
        <input value={fields.date} onChange={e => set('date', e.target.value)} placeholder={locale === 'ar' ? 'مثال: 12/07/2026 · صباحاً' : 'ex. 12/07/2026 · matin'} style={inp('date')} />
      </div>
      <div>
        <label style={{ display: 'block', fontSize: 13, color: '#988F84', marginBottom: 7, fontWeight: 600 }}>{u.f_goals}</label>
        <textarea value={fields.goals} onChange={e => set('goals', e.target.value)} style={{ ...inp('goals'), minHeight: 110, resize: 'vertical' }} />
      </div>
      <button type="submit" style={{ background: '#C8602B', color: '#160F0B', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.04em', fontSize: 15, padding: 16, borderRadius: 2 }}>{u.insc_submit}</button>
    </form>
  );
}
