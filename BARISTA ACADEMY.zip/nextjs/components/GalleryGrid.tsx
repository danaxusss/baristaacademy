'use client';
import { useState } from 'react';
import type { GalleryCat } from '@/lib/content';
import { galleryMap } from '@/lib/content';

interface Props {
  galleryCats: GalleryCat[];
  certTitle: string;
  certSub: string;
  logoSrc?: string;
}

export default function GalleryGrid({ galleryCats, certTitle, certSub }: Props) {
  const [cat, setCat] = useState('all');
  const items = cat === 'all' ? galleryMap : galleryMap.filter(g => g.cats.includes(cat));
  const showCert = cat === 'certificats';

  const chipStyle = (token: string): React.CSSProperties => ({
    padding: '9px 16px', fontSize: 13, fontWeight: 600, letterSpacing: '.02em',
    borderRadius: 2, cursor: 'pointer', whiteSpace: 'nowrap',
    border: `1px solid ${cat === token ? '#C8602B' : 'rgba(255,255,255,.16)'}`,
    background: cat === token ? '#C8602B' : 'transparent',
    color: cat === token ? '#160F0B' : '#C9C0B5',
  });

  return (
    <>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10, marginBottom: 36 }}>
        {galleryCats.map(g => (
          <button key={g.token} onClick={() => setCat(g.token)} style={chipStyle(g.token)}>{g.label}</button>
        ))}
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(240px,1fr))', gap: 14 }}>
        {items.map((g, i) => (
          <div key={i} style={{ overflow: 'hidden', borderRadius: 5, border: '1px solid rgba(255,255,255,.08)', aspectRatio: '1/1.18' }}>
            <img src={g.src} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover', transition: 'transform .5s', display: 'block' }} />
          </div>
        ))}
      </div>
      {showCert && (
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center', padding: '60px 24px', border: '1px dashed rgba(255,255,255,.16)', borderRadius: 8, marginTop: 8 }}>
          <img src="/assets/logo-shield-white.png" style={{ height: 90, opacity: .7, marginBottom: 22 }} alt="" />
          <h3 style={{ fontFamily: 'var(--font-display)', fontWeight: 400, fontSize: 26, textTransform: 'uppercase', marginBottom: 10 }}>{certTitle}</h3>
          <p style={{ color: '#988F84', maxWidth: 420 }}>{certSub}</p>
        </div>
      )}
    </>
  );
}
