'use client';
import { useState, FormEvent } from 'react';
import type { LocaleContent } from '@/lib/content';

interface Props { locale: string; c: LocaleContent; fonts: { display: string; body: string }; onClose: () => void; }

export default function BookingModal({ locale, c, fonts, onClose }: Props) {
  const u = c.ui;
  const [fields, setFields] = useState({ name: '', phone: '', program: c.programs[0].key, session: c.sessions[0].key });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [sent, setSent] = useState(false);

  const set = (k: string, v: string) => {
    setFields(f => ({ ...f, [k]: v }));
    setErrors(e => ({ ...e, [k]: '' }));
  };

  const validate = () => {
    const e: Record<string, string> = {};
    if (!fields.name.trim()) e.name = u.err_required;
    if (!fields.phone.trim()) e.phone = u.err_required;
    else if (!/[0-9]{6,}/.test(fields.phone.replace(/\s/g, ''))) e.phone = u.err_phone;
    return e;
  };

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length) { setErrors(errs); return; }
    setSent(true);
  };

  const progName = c.programs.find(p => p.key === fields.program)?.name ?? fields.program;
  const waText = locale === 'ar'
    ? `مرحباً، أرغب في حجز مقعد في أكاديمية الباريستا.%0Aالاسم: ${fields.name}%0Aالهاتف: ${fields.phone}%0Aالتكوين: ${progName}`
    : `Bonjour, je souhaite réserver une place à Barista Moroccan Academy.%0ANom: ${fields.name}%0ATéléphone: ${fields.phone}%0AFormation: ${progName}`;
  const waLink = `https://wa.me/212657116631?text=${waText}`;

  const inputStyle = (k: string): React.CSSProperties => ({
    width: '100%', background: '#100C09', border: `1px solid ${errors[k] ? '#7a3a2a' : 'rgba(255,255,255,.14)'}`,
    color: '#F4EEE6', padding: '13px 14px', borderRadius: 3, fontSize: 15, outline: 'none',
  });

  return (
    <div onClick={onClose} style={{ position: 'fixed', inset: 0, zIndex: 80, background: 'rgba(6,5,5,.8)', backdropFilter: 'blur(6px)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
      <div onClick={e => e.stopPropagation()} dir={c.dir} style={{ width: '100%', maxWidth: 480, background: '#15110D', border: '1px solid rgba(255,255,255,.12)', borderRadius: 8, overflow: 'hidden', maxHeight: '92vh', overflowY: 'auto' }}>
        {/* Header */}
        <div style={{ position: 'relative', padding: '26px 28px', borderBottom: '1px solid rgba(255,255,255,.08)', background: 'linear-gradient(120deg,#1C130D,#15110D)' }}>
          <button onClick={onClose} style={{ position: 'absolute', top: 16, insetInlineEnd: 16, width: 36, height: 36, border: '1px solid rgba(255,255,255,.16)', borderRadius: 2, color: '#C9C0B5', fontSize: 18 }}>✕</button>
          <div style={{ fontSize: 12, fontWeight: 700, letterSpacing: '.14em', textTransform: 'uppercase', color: '#E0A35A', marginBottom: 8 }}>{u.book_tag}</div>
          <h3 style={{ fontFamily: fonts.display, fontWeight: 400, fontSize: 30, textTransform: 'uppercase', lineHeight: 1 }}>{u.book_title}</h3>
        </div>

        {sent ? (
          <div style={{ padding: '40px 28px', textAlign: 'center' }}>
            <div style={{ width: 64, height: 64, borderRadius: '50%', background: 'rgba(224,163,90,.15)', border: '1px solid rgba(224,163,90,.45)', color: '#E0A35A', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 30, margin: '0 auto 20px' }}>✓</div>
            <h4 style={{ fontFamily: fonts.display, fontWeight: 400, fontSize: 24, textTransform: 'uppercase', marginBottom: 10 }}>{u.form_ok_title}</h4>
            <p style={{ color: '#988F84', fontSize: 15, marginBottom: 24 }}>{u.form_ok_sub}</p>
            <a href={waLink} target="_blank" rel="noreferrer" style={{ display: 'inline-flex', alignItems: 'center', gap: 10, background: '#C8602B', color: '#160F0B', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.04em', fontSize: 14, padding: '15px 26px', borderRadius: 2 }}>{u.cta_whatsapp} →</a>
          </div>
        ) : (
          <form onSubmit={onSubmit} style={{ padding: '26px 28px', display: 'flex', flexDirection: 'column', gap: 16 }}>
            <div>
              <label style={{ display: 'block', fontSize: 13, color: '#988F84', marginBottom: 7, fontWeight: 600 }}>{u.f_name}</label>
              <input value={fields.name} onChange={e => set('name', e.target.value)} style={inputStyle('name')} />
              {errors.name && <div style={{ color: '#E07A5A', fontSize: 12.5, marginTop: 5 }}>{errors.name}</div>}
            </div>
            <div>
              <label style={{ display: 'block', fontSize: 13, color: '#988F84', marginBottom: 7, fontWeight: 600 }}>{u.f_phone}</label>
              <input value={fields.phone} onChange={e => set('phone', e.target.value)} placeholder="+212 6.. .. .. .." style={inputStyle('phone')} />
              {errors.phone && <div style={{ color: '#E07A5A', fontSize: 12.5, marginTop: 5 }}>{errors.phone}</div>}
            </div>
            <div>
              <label style={{ display: 'block', fontSize: 13, color: '#988F84', marginBottom: 7, fontWeight: 600 }}>{u.f_program}</label>
              <select value={fields.program} onChange={e => set('program', e.target.value)} style={{ ...inputStyle('program'), appearance: 'none' }}>
                {c.programs.map(p => <option key={p.key} value={p.key}>{p.name} — {p.dur}</option>)}
              </select>
            </div>
            <div>
              <label style={{ display: 'block', fontSize: 13, color: '#988F84', marginBottom: 7, fontWeight: 600 }}>{u.f_session}</label>
              <select value={fields.session} onChange={e => set('session', e.target.value)} style={{ ...inputStyle('session'), appearance: 'none' }}>
                {c.sessions.map(s => <option key={s.key} value={s.key}>{s.title}</option>)}
              </select>
            </div>
            <button type="submit" style={{ marginTop: 6, background: '#C8602B', color: '#160F0B', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.04em', fontSize: 15, padding: 16, borderRadius: 2 }}>{u.book_submit}</button>
            <p style={{ fontSize: 12, color: '#776E64', textAlign: 'center' }}>{u.book_note}</p>
          </form>
        )}
      </div>
    </div>
  );
}
