'use client';
import { useState } from 'react';
import Link from 'next/link';
import type { Program, Filter } from '@/lib/content';
import { useModal } from './ModalProvider';

interface Props {
  programs: Program[];
  filters: Filter[];
  locale: string;
  ui: Record<string, string>;
  fonts: { display: string; body: string };
}

export default function FormationsGrid({ programs, filters, locale, ui, fonts }: Props) {
  const [active, setActive] = useState('all');
  const { openBooking } = useModal();
  const visible = active === 'all' ? programs : programs.filter(p => p.level === active);

  const chipStyle = (token: string): React.CSSProperties => ({
    padding: '10px 18px', fontSize: 13.5, fontWeight: 600, letterSpacing: '.02em',
    borderRadius: 2, cursor: 'pointer', textTransform: 'uppercase', whiteSpace: 'nowrap',
    border: `1px solid ${active === token ? '#C8602B' : 'rgba(255,255,255,.16)'}`,
    background: active === token ? '#C8602B' : 'transparent',
    color: active === token ? '#160F0B' : '#C9C0B5',
  });

  return (
    <>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10, marginBottom: 40 }}>
        {filters.map(f => <button key={f.token} onClick={() => setActive(f.token)} style={chipStyle(f.token)}>{f.label}</button>)}
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(320px,1fr))', gap: 22 }}>
        {visible.map(p => (
          <div key={p.key} style={{ background: '#16110D', border: `1px solid ${p.featured ? 'rgba(200,96,43,.5)' : 'rgba(255,255,255,.08)'}`, borderRadius: 7, overflow: 'hidden', display: 'flex', flexDirection: 'column', transition: 'transform .35s' }}>
            <div style={{ position: 'relative', height: 210, overflow: 'hidden' }}>
              <img src={p.img} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
              <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg,transparent 45%,rgba(14,13,12,.92))' }} />
              {p.featured && <div style={{ position: 'absolute', top: 14, insetInlineStart: 14, background: '#C8602B', color: '#160F0B', fontSize: 11, fontWeight: 700, letterSpacing: '.1em', textTransform: 'uppercase', padding: '6px 11px', borderRadius: 2, whiteSpace: 'nowrap' }}>{ui.featured}</div>}
              <div style={{ position: 'absolute', bottom: 14, insetInlineStart: 18, display: 'flex', gap: 8, alignItems: 'center' }}>
                <span style={{ background: 'rgba(255,255,255,.12)', border: '1px solid rgba(255,255,255,.2)', fontSize: 11, fontWeight: 600, letterSpacing: '.06em', textTransform: 'uppercase', padding: '5px 10px', borderRadius: 2, whiteSpace: 'nowrap' }}>{p.levelLabel}</span>
                <span style={{ fontSize: 13, color: '#E0A35A', fontWeight: 600, whiteSpace: 'nowrap' }}>{p.dur}</span>
              </div>
            </div>
            <div style={{ padding: '26px 26px 30px', display: 'flex', flexDirection: 'column', flex: 1 }}>
              <h3 style={{ fontFamily: fonts.display, fontWeight: 400, fontSize: 29, textTransform: 'uppercase', lineHeight: 1, marginBottom: 12 }}>{p.name}</h3>
              <p style={{ color: '#988F84', fontSize: 15, marginBottom: 22 }}>{p.desc}</p>
              <div style={{ fontSize: 12, fontWeight: 700, letterSpacing: '.1em', textTransform: 'uppercase', color: '#776E64', marginBottom: 12 }}>{ui.included}</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 24 }}>
                {p.points.map((pt, i) => (
                  <div key={i} style={{ display: 'flex', gap: 11, alignItems: 'flex-start', fontSize: 14.5, lineHeight: 1.35, color: '#D7CFC4' }}>
                    <span style={{ color: '#C8602B', fontWeight: 700, flexShrink: 0 }}>✓</span><span>{pt}</span>
                  </div>
                ))}
              </div>
              <div style={{ marginTop: 'auto', borderTop: '1px solid rgba(255,255,255,.08)', paddingTop: 20 }}>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginBottom: 16 }}>
                  <div dir="ltr" style={{ fontFamily: fonts.display, fontSize: 28, color: '#F4EEE6', lineHeight: 1, whiteSpace: 'nowrap' }}>{p.price}</div>
                  <div dir="ltr" style={{ fontSize: 12.5, color: '#776E64' }}>{p.priceNote}</div>
                </div>
                <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
                  <Link href={`/${locale}/inscription`} style={{ flex: 1, minWidth: 130, background: '#C8602B', color: '#160F0B', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.03em', fontSize: 13.5, padding: '13px 16px', borderRadius: 2, textAlign: 'center', display: 'block' }}>{ui.cta_enroll}</Link>
                  <button onClick={openBooking} style={{ border: '1px solid rgba(255,255,255,.24)', color: '#F4EEE6', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '.03em', fontSize: 13.5, padding: '13px 16px', borderRadius: 2 }}>{ui.cta_book}</button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}
