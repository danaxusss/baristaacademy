'use client';
import { useState, FormEvent } from 'react';

interface Props { locale: string; placeholder: string; successMsg: string; }

export default function NewsletterForm({ placeholder, successMsg }: Props) {
  const [email, setEmail] = useState('');
  const [sent, setSent] = useState(false);

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;
    setSent(true);
  };

  if (sent) return (
    <div style={{ background: 'rgba(224,163,90,.12)', border: '1px solid rgba(224,163,90,.4)', color: '#E0A35A', fontSize: 13.5, padding: 14, borderRadius: 3 }}>{successMsg}</div>
  );

  return (
    <form onSubmit={onSubmit} style={{ display: 'flex', gap: 8 }}>
      <input
        type="email"
        value={email}
        onChange={e => setEmail(e.target.value)}
        placeholder={placeholder}
        style={{ flex: 1, background: '#15110D', border: '1px solid rgba(255,255,255,.14)', color: '#F4EEE6', padding: '13px 14px', borderRadius: 3, fontSize: 14, minWidth: 0 }}
      />
      <button type="submit" style={{ background: '#C8602B', color: '#160F0B', fontWeight: 700, padding: '0 18px', borderRadius: 3, fontSize: 18 }}>→</button>
    </form>
  );
}
