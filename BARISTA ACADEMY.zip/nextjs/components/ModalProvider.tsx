'use client';
import { createContext, useContext, useState, ReactNode } from 'react';
import Header from './Header';
import Footer from './Footer';
import BookingModal from './BookingModal';
import type { LocaleContent } from '@/lib/content';

interface ModalCtx { openBooking: () => void; closeBooking: () => void; }
const ModalContext = createContext<ModalCtx>({ openBooking: () => {}, closeBooking: () => {} });
export const useModal = () => useContext(ModalContext);

interface Props {
  locale: string;
  content: LocaleContent;
  fonts: { display: string; body: string };
  children: ReactNode;
}

export default function ModalProvider({ locale, content, fonts, children }: Props) {
  const [bookingOpen, setBookingOpen] = useState(false);
  const c = content;

  return (
    <ModalContext.Provider value={{ openBooking: () => setBookingOpen(true), closeBooking: () => setBookingOpen(false) }}>
      <div
        data-lang={locale}
        dir={c.dir}
        style={{ minHeight: '100vh', background: '#0E0D0C', color: '#F4EEE6', fontFamily: fonts.body, fontSize: 17, lineHeight: 1.6, overflowX: 'hidden' }}
      >
        <Header locale={locale} c={c} fonts={fonts} onOpenBooking={() => setBookingOpen(true)} />
        <main>{children}</main>
        <Footer locale={locale} c={c} />
        {bookingOpen && (
          <BookingModal locale={locale} c={c} fonts={fonts} onClose={() => setBookingOpen(false)} />
        )}
      </div>
    </ModalContext.Provider>
  );
}
