'use client';
import { useModal } from './ModalProvider';

interface Props { label: string; style?: React.CSSProperties; className?: string; }

export default function OpenBookingButton({ label, style, className }: Props) {
  const { openBooking } = useModal();
  return (
    <button onClick={openBooking} style={style} className={className}>{label}</button>
  );
}
