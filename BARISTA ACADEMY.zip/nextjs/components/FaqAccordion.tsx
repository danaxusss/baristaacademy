'use client';
import { useState } from 'react';
import type { FAQ } from '@/lib/content';

interface Props { faqs: FAQ[]; fonts: { display: string; body: string }; }

export default function FaqAccordion({ faqs, fonts }: Props) {
  const [open, setOpen] = useState<number>(0);
  return (
    <div style={{ maxWidth: 820, margin: '0 auto' }}>
      {faqs.map((f, i) => (
        <div key={i} style={{ borderBottom: '1px solid rgba(255,255,255,.1)' }}>
          <button
            onClick={() => setOpen(open === i ? -1 : i)}
            style={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 20, textAlign: 'start', padding: '24px 0', color: '#F4EEE6', background: 'none', border: 'none', cursor: 'pointer' }}
          >
            <span style={{ fontSize: 'clamp(17px,2.2vw,20px)', fontWeight: 600 }}>{f.q}</span>
            <span style={{ color: open === i ? '#C8602B' : '#C9C0B5', fontSize: 26, fontFamily: fonts.display, lineHeight: 1, flexShrink: 0 }}>{open === i ? '–' : '+'}</span>
          </button>
          <div style={{ maxHeight: open === i ? 300 : 0, overflow: 'hidden', transition: 'max-height .35s ease, padding .35s ease', paddingBottom: open === i ? 22 : 0 }}>
            <p style={{ color: '#988F84', fontSize: 16, maxWidth: 680 }}>{f.a}</p>
          </div>
        </div>
      ))}
    </div>
  );
}
