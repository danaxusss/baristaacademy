import Link from 'next/link';
import NewsletterForm from './NewsletterForm';
import type { LocaleContent } from '@/lib/content';

const NAV_PAGES = ['formations', 'programme', 'tarifs', 'galerie', 'blog', 'faq', 'contact'] as const;

interface Props { locale: string; c: LocaleContent; }

export default function Footer({ locale, c }: Props) {
  const u = c.ui;
  const link = (page: string) => page === 'home' ? `/${locale}` : `/${locale}/${page}`;

  return (
    <footer style={{ background: '#0A0908', borderTop: '1px solid rgba(255,255,255,.08)', padding: '64px 24px 32px' }}>
      <div style={{ maxWidth: 1240, margin: '0 auto' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(220px,1fr))', gap: 40, paddingBottom: 48, borderBottom: '1px solid rgba(255,255,255,.08)' }}>
          {/* Brand */}
          <div>
            <img src="/assets/logo-shield-white.png" alt="Barista Moroccan Academy" style={{ height: 96, width: 'auto', marginBottom: 18 }} />
            <p style={{ color: '#776E64', fontSize: 14, maxWidth: 280 }}>{u.footer_tagline}</p>
          </div>

          {/* Nav */}
          <div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 18, textTransform: 'uppercase', letterSpacing: '.04em', color: '#988F84', marginBottom: 18 }}>{u.footer_nav}</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 11 }}>
              {NAV_PAGES.map(page => (
                <Link key={page} href={link(page)} style={{ color: '#C9C0B5', fontSize: 14.5 }}>{c.nav[page]}</Link>
              ))}
            </div>
          </div>

          {/* Contact */}
          <div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 18, textTransform: 'uppercase', letterSpacing: '.04em', color: '#988F84', marginBottom: 18 }}>{u.footer_contact}</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12, color: '#C9C0B5', fontSize: 14.5 }}>
              <a href="https://wa.me/212657116631" target="_blank" rel="noreferrer" style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <span style={{ color: '#C8602B' }}>✆</span> +212 657 116 631
              </a>
              <a href="mailto:contact@wedrinks.ma" style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <span style={{ color: '#C8602B' }}>✉</span> contact@wedrinks.ma
              </a>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <span style={{ color: '#C8602B' }}>⚲</span> {u.footer_address}
              </div>
            </div>
          </div>

          {/* Newsletter */}
          <div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 18, textTransform: 'uppercase', letterSpacing: '.04em', color: '#988F84', marginBottom: 18 }}>{u.footer_news}</div>
            <p style={{ color: '#776E64', fontSize: 13.5, marginBottom: 14 }}>{u.footer_news_sub}</p>
            <NewsletterForm locale={locale} placeholder={u.email_ph} successMsg={u.news_ok} />
          </div>
        </div>

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 12, paddingTop: 28, color: '#5E564E', fontSize: 13 }}>
          <div>© 2026 Barista Moroccan Academy — by STE Wedrinks</div>
          <div>{u.footer_made}</div>
        </div>
      </div>
    </footer>
  );
}
