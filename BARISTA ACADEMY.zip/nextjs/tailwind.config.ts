import type { Config } from 'tailwindcss';

const config: Config = {
  content: [
    './app/**/*.{ts,tsx}',
    './components/**/*.{ts,tsx}',
    './lib/**/*.ts',
  ],
  theme: {
    extend: {
      colors: {
        canvas:   '#0E0D0C',
        espresso: '#120D0A',
        dark:     '#16110D',
        mocha:    '#15110D',
        cream:    '#F4EEE6',
        muted:    '#C9C0B5',
        faint:    '#988F84',
        dim:      '#776E64',
        ghost:    '#5E564E',
        terra:    '#C8602B',
        amber:    '#E0A35A',
        'terra-deep': '#160F0B',
      },
    },
  },
  plugins: [],
};

export default config;
